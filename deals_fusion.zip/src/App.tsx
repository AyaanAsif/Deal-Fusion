import "./App.css";
import { Route, Routes } from "react-router-dom";
import HomePage from "./pages/HomePage";
import AllStoresPage from "./pages/AllStoresPage";
import CategoriesPage from "./pages/CategoriesPage";
import StoreCompaignPage from "./pages/StoreCompaignPage";
import CategoriesDetailsPage from "./pages/CategoryDetailsPage";
import AboutUsPage from "./pages/AboutUsPage";
import LogInPage from "./pages/LogInPage";
import ForgotPage from "./pages/ForgotPage";
import EmailCheckingPage from "./pages/EmailChecking";
import RegisterPage from "./pages/RegisterPage";
import TermsAndConditionsPage from "./pages/TermsAndConditionPage";
import PrivacyPolicyPage from "./pages/PrivacyPolicy";
import BlogsPage from "./pages/BlogsPage";
import StoreDetailsPage from "./pages/StoreDetailPage";
import ErrorPage from "./pages/ErrorPage";
import BlogDetailsPage from "./pages/BlogDetailsPage";
import CouponsPage from "./pages/CategoriesPage";

function App() {
  return (
    <>
      <Routes>
        <Route index element={<HomePage />}></Route>
        <Route path="/store-compaigns" element={<StoreCompaignPage />}></Route>
        <Route path="/all-stores" element={<AllStoresPage />}></Route>
        <Route path="/coupons" element={<CouponsPage />}></Route>
        <Route
          path="/category-details"
          element={<CategoriesDetailsPage />}
        ></Route>
        <Route path="/about-us" element={<AboutUsPage />}></Route>
        <Route path="/login" element={<LogInPage />}></Route>
        <Route path="/register" element={<RegisterPage />}></Route>
        <Route path="/forgot-password" element={<ForgotPage />}></Route>
        <Route path="/email-checking" element={<EmailCheckingPage />}></Route>
        <Route path="/terms-and-conditions" element={<TermsAndConditionsPage />}></Route>
        <Route path="/privacy-policy" element={<PrivacyPolicyPage />}></Route>
        <Route path="/blogs" element={<BlogsPage />}></Route>
        <Route path="/store-details" element={<StoreDetailsPage />}></Route>
        <Route path="/blog-details" element={<BlogDetailsPage />}></Route>
        <Route path="/404" element={<ErrorPage />}></Route>
      </Routes>
    </>
  );
}

export default App;

// export const storeDetailsData = [
//   {
//     id: 1,
//     storeName: "Adidas",
//     storeHeading: "Adidas Coupons & Promo Codes",
//     storeDescription: "Top 47 offers available for july 2023",
//     couponDetails: [
//       {
//         id: 1,
//         couponType: "Show Code",
//         discount: ["upto", "70%", "cashback"],
//         couponHeading:
//           "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
//         couponDates: "Expiry : July 30, 2023",
//         couponDetails: {
//           description:
//             "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
//           sellingDetails:
//             "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
//           expiryDetails: "Hurry up, Offer expire in 12 days",
//           couponVerfication: "Deals Verified",
//         },
//       },
//       {
//         id: 2,
//         couponType: "Show Code",
//         couponCode: "CODE1423",
//         discount: ["upto", "70%", "cashback"],
//         couponHeading:
//           "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
//         couponDates: "Expiry : July 30, 2023",
//         couponDetails: {
//           description:
//             "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
//           sellingDetails:
//             "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
//           expiryDetails: "Hurry up, Offer expire in 12 days",
//           couponVerfication: "Deals Verified",
//         },
//       },
//       {
//         id: 3,
//         couponType: "Get Deal",
//         couponCode: "CODE1423",
//         discount: ["upto", "70%", "cashback"],
//         couponHeading:
//           "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
//         couponDates: "Expiry : July 30, 2023",
//         couponDetails: {
//           description:
//             "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
//           sellingDetails:
//             "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
//           expiryDetails: "Hurry up, Offer expire in 12 days",
//           couponVerfication: "Deals Verified",
//         },
//       },
//     ],
//   },
// ];

export const storeDescription = {
  id: 1,
  storeName: "Adidas",
  storeImage: "/images/stores/adidas.png",
  description:
    "Over 50+ offers avaible, items are moving fast. Act now if you want one of your own!",
  todayOffer: "Today's adidas Top Offers:",
  firstOffer: "Shop The Latest Trends Under $100",
  secondOffer: "6% Cash Back For Purcahses Sitewide",
  totalOffer: "50",
  couponCode: "6",
  deals: "10",
  bestDiscount: "30% off",
  cashBackOffer: "6%",
  aboutDescription:
    "In 1924, adidas was founded in Herzogenaurach, Germany, as 'Dassler Brothers Shoe Factory.'",
  moreDescription:
    "Adolf Dassler started the business in his mother's house, and his older brother Rudolf helped him develop spiked running shoes.",
  storeSavingHacks:
    "Does adidas offer a discount if I sign up for their email newsletter?",
  storeHacksDescription:
    "Yesm receive 15% off your next order when you sign up for the adidas email newsletter.",
};

export const storeDetailsData = [
  {
    id: 1,
    couponType: "Get Deal",
    discount: ["70%", "cashback"],
    couponHeading:
      "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
    couponDates: "Expiry : July 30, 2023",
    couponDetails: {
      description:
        "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
      sellingDetails:
        "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
      expiryDetails: "Hurry up, Offer expire in 12 days",
      couponVerfication: "Deals Verified",
    },
  },
  {
    id: 2,
    couponType: "Get Deal",
    couponCode: "CODE1423",
    discount: ["50%", "cashback"],
    couponHeading:
      "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
    couponDates: "Expiry : July 30, 2023",
    couponDetails: {
      description:
        "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
      sellingDetails:
        "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
      expiryDetails: "Hurry up, Offer expire in 12 days",
      couponVerfication: "Deals Verified",
    },
  },
  {
    id: 3,
    couponType: "Get Deal",
    couponCode: "CODE1423",
    discount: ["FREE", "Shipping"],
    couponHeading:
      "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
    couponDates: "Expiry : July 30, 2023",
    couponDetails: {
      description:
        "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
      sellingDetails:
        "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
      expiryDetails: "Hurry up, Offer expire in 12 days",
      couponVerfication: "Deals Verified",
    },
  },
  {
    id: 4,
    couponType: "Show Code",
    couponCode: "CODE1423",
    discount: ["70%", "off"],
    couponHeading:
      "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
    couponDates: "Expiry : July 30, 2023",
    couponDetails: {
      description:
        "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
      sellingDetails:
        "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
      expiryDetails: "Hurry up, Offer expire in 12 days",
      couponVerfication: "Deals Verified",
    },
  },
  {
    id: 5,
    couponType: "Get Deal",
    couponCode: "CODE1423",
    discount: ["SALE", ""],
    couponHeading:
      "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
    couponDates: "Expiry : July 30, 2023",
    couponDetails: {
      description:
        "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
      sellingDetails:
        "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
      expiryDetails: "Hurry up, Offer expire in 12 days",
      couponVerfication: "Deals Verified",
    },
  },
  {
    id: 6,
    couponType: "Get Deal",
    couponCode: "CODE1423",
    discount: ["70%", "off"],
    couponHeading:
      "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
    couponDates: "Expiry : July 30, 2023",
    couponDetails: {
      description:
        "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
      sellingDetails:
        "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
      expiryDetails: "Hurry up, Offer expire in 12 days",
      couponVerfication: "Deals Verified",
    },
  },
  {
    id: 7,
    couponType: "Get Deal",
    discount: ["70%", "cashback"],
    couponHeading:
      "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
    couponDates: "Expiry : July 30, 2023",
    couponDetails: {
      description:
        "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
      sellingDetails:
        "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
      expiryDetails: "Hurry up, Offer expire in 12 days",
      couponVerfication: "Deals Verified",
    },
  },
  {
    id: 8,
    couponType: "Show Code",
    couponCode: "CODE1423",
    discount: ["50%", "cashback"],
    couponHeading:
      "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
    couponDates: "Expiry : July 30, 2023",
    couponDetails: {
      description:
        "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
      sellingDetails:
        "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
      expiryDetails: "Hurry up, Offer expire in 12 days",
      couponVerfication: "Deals Verified",
    },
  },
  {
    id: 9,
    couponType: "Get Deal",
    couponCode: "CODE1423",
    discount: ["FREE", "Shipping"],
    couponHeading:
      "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
    couponDates: "Expiry : July 30, 2023",
    couponDetails: {
      description:
        "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
      sellingDetails:
        "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
      expiryDetails: "Hurry up, Offer expire in 12 days",
      couponVerfication: "Deals Verified",
    },
  },
  {
    id: 10,
    couponType: "Show Code",
    couponCode: "CODE1423",
    discount: ["70%", "cashback"],
    couponHeading:
      "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
    couponDates: "Expiry : July 30, 2023",
    couponDetails: {
      description:
        "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
      sellingDetails:
        "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
      expiryDetails: "Hurry up, Offer expire in 12 days",
      couponVerfication: "Deals Verified",
    },
  },
  {
    id: 11,
    couponType: "Get Deal",
    couponCode: "CODE1423",
    discount: ["SALE", ""],
    couponHeading:
      "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
    couponDates: "Expiry : July 30, 2023",
    couponDetails: {
      description:
        "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
      sellingDetails:
        "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
      expiryDetails: "Hurry up, Offer expire in 12 days",
      couponVerfication: "Deals Verified",
    },
  },
  {
    id: 12,
    couponType: "Get Deal",
    couponCode: "CODE1423",
    discount: ["70%", "off"],
    couponHeading:
      "Summer Sale! 30% off Full Price & Sale Items + Up to 60% off",
    couponDates: "Expiry : July 30, 2023",
    couponDetails: {
      description:
        "Combine with other offers for an even better deal! Cash back is earned on the qualifying purchase total after any discounts and before any fees, taxes, or shipping and handling are applied.",
      sellingDetails:
        "Over 350 sold today, this item is moving fast. Act now if you want one of your own!",
      expiryDetails: "Hurry up, Offer expire in 12 days",
      couponVerfication: "Deals Verified",
    },
  },
];

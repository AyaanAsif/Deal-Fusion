import React from "react";
import ForgotPassword from "../Components/ForgotPassword";

const ForgotPage: React.FC = () => {
    return (
        <>
        <ForgotPassword/>
        </>
    )
}

export default ForgotPage;
import React from "react";
import EmailChecking from "../Components/EmailChecking";

const EmailCheckingPage = () => {
    return (
        <>
        <EmailChecking/>
        </>
    )
}

export default EmailCheckingPage;
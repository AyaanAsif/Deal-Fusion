import React from "react";
import Error404 from "../Components/Global/Error404";
import MainLayout from "../Components/Layout/MainLayout";

const ErrorPage: React.FC = () => {
  return (
    <MainLayout>
      <Error404 />
    </MainLayout>
  );
};

export default ErrorPage;

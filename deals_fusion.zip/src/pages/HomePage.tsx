import React from "react";
import MainLayout from "../Components/Layout/MainLayout";
import Home from "../Components/Home";

const HomePage: React.FC = () => {
    return (
        <MainLayout>
        <Home/>
        </MainLayout>
    )
}

export default HomePage;
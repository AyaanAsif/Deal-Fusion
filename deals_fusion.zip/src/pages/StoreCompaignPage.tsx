import React from "react";
import MainLayout from "../Components/Layout/MainLayout";
import StoreCompaign from "../Components/StoreCompaign";

const StoreCompaignPage: React.FC = () => {
    return (
        <MainLayout>
        <StoreCompaign/>
        </MainLayout>
    )

}

export default StoreCompaignPage;
import React from "react";
import MainLayout from "../Components/Layout/MainLayout";
import Coupons from "../Components/Coupons";

const CouponsPage: React.FC = () => {
    return (
        <MainLayout>
        <Coupons/>
        </MainLayout>
    )
}

export default CouponsPage;
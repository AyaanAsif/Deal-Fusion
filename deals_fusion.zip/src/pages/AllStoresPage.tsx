import React from "react";
import AllStores from "../Components/AllStores";
import MainLayout from "../Components/Layout/MainLayout";

const AllStoresPage: React.FC = () => {
    return (
        <MainLayout>
        <AllStores/>
        </MainLayout>
    )
}

export default AllStoresPage;
import React from 'react'
import Blogs from '../Components/Blogs';
import MainLayout from '../Components/Layout/MainLayout';

const BlogsPage: React.FC = () => {
    return (
        <MainLayout>
        <Blogs/>
        </MainLayout>
    )
}

export default BlogsPage;
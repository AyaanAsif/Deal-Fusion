import React from "react"
import TermsAndConditions from "../Components/TermsAndConditions";
import MainLayout from "../Components/Layout/MainLayout";

const TermsAndConditionsPage: React.FC = () => {
    return (
        <MainLayout>
        <TermsAndConditions/>
        </MainLayout>
    )
}

export default TermsAndConditionsPage;
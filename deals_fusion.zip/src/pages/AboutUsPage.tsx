import React from "react";
import MainLayout from "../Components/Layout/MainLayout";
import AboutUs from "../Components/AboutUs";

const AboutUsPage: React.FC = () => {
    return (
        <MainLayout>
        <AboutUs/>
        </MainLayout>
    )
}

export default AboutUsPage;
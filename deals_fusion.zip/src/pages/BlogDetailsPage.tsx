import React from "react";
import BlogDetails from "../Components/BlogDetails";
import MainLayout from "../Components/Layout/MainLayout";

const BlogDetailsPage: React.FC = () => {
  return (
    <MainLayout>
      <BlogDetails />
    </MainLayout>
  );
};

export default BlogDetailsPage;

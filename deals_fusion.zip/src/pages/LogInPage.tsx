import React from "react";
import RegistrationSteps from "../Components/Login";
import Login from "../Components/Login";

const LogInPage: React.FC = () => {
    return (
        <>
        <Login/>
        </>
    )
}

export default LogInPage;
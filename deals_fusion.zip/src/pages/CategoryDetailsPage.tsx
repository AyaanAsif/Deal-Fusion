import React from "react";
import MainLayout from "../Components/Layout/MainLayout";
import CategoriesDetails from "../Components/CategoriesDetails";

const CategoriesDetailsPage: React.FC = () => {
  return (
    <MainLayout>
      <CategoriesDetails />
    </MainLayout>
  );
};

export default CategoriesDetailsPage;

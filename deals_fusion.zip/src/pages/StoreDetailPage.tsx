import React from 'react'
import MainLayout from '../Components/Layout/MainLayout';
import StoreDetails from '../Components/StoreDetails';

const StoreDetailsPage: React.FC = () => {
    return (
        <MainLayout>
        <StoreDetails/>
        </MainLayout>
    )
}

export default StoreDetailsPage;
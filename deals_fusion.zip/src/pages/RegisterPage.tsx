import React from "react";
import Register from "../Components/Register";

const RegisterPage: React.FC = () => {
    return (
        <>
        <Register/>
        </>
    )
}

export default RegisterPage;
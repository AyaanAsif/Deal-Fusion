import React from 'react'
import PrivacyPolicy from '../Components/PrivacyPolicy';
import MainLayout from '../Components/Layout/MainLayout';

const PrivacyPolicyPage: React.FC = () => {
    return (
        <MainLayout>
        <PrivacyPolicy/>
        </MainLayout>
    )
}

export default PrivacyPolicyPage;
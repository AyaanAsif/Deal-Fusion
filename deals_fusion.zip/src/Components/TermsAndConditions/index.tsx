import React from "react";

const TermsAndConditions: React.FC = () => {
  return (
    <>
      <div className="inner-banner flex justify-center items-center">
        <h1 className="font-montserrat sm:text-3xl text-xl font-semibold text-white">
          Terms & Conditions
        </h1>
      </div>
      <div className="2xl:container mx-auto 2xl:px-0 xl:px-20 lg:px-10 px-5 py-20">
        <h2 className="text-header-bg font-montserrat sm:text-4xl text-2xl font-semibold">
          Subscription Terms & Conditions
        </h2>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          These Membership Terms & Conditions (the “Agreement”) govern your use
          of and participation in a Program (as defined in Inner Balance’s Terms
          of Use). This Agreement does not apply if you signed up for a Program
          through an employer. This Agreement incorporates by reference and
          shall be fully subject to our Terms of Use. All terms not defined
          herein shall have the meaning in our Terms of Use.
        </p>
        <h4 className="mt-8 font-montserrat text-xl font-semibold text-header-bg">
          1. Subscription Options.
        </h4>
        <div className="flex items-start gap-3 mt-6">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins sm:text-base text-sm">
            Inner Balance offers various Programs for subscription
            (“Subscription Options”), each with its own services and fees
            (“Subscription Fees”). Any payment terms presented to you during the
            process of using or signing up for a Subscription Option are deemed
            part of this Agreement. If fees are not paid when due, you may be
            terminated from the Program and no longer have access to the
            Services.
          </p>
        </div>
        <div className="flex items-start gap-3 mt-6">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins sm:text-base text-sm">
            You are solely responsible for payment of all Subscription Fees.
            Inner Balance uses a third-party payment processor (the “Payment
            Processor”) to collect Fees (your “Billing Account”). Processing of
            payments is subject to the terms, conditions and privacy policies of
            the Payment Processor in addition to this Agreement. Currently,
            Inner Balance uses Stripe as our Payment Processor. You can access
            Stripe’s Terms of Service at https://stripe.com/legal/end-users and
            their Privacy Policy at https://stripe.com/privacy. Inner Balance is
            not responsible for any acts or omissions of the Payment Processor.
          </p>
        </div>
        <div className="flex items-start gap-3 mt-6">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins sm:text-base text-sm">
            By choosing to use or otherwise participate in a subscription, you
            agree to: 1{")"} pay Inner Balance, through the Payment Processor,
            the Subscription Fees for the Subscription Option you have selected
            in accordance with the applicable payment terms; and 2{")"} you
            authorize Inner Balance, through the Payment Processor, to charge
            your bank, financial institution or credit credit card (your
            “Payment Method”) for all payments due. Inner Balance reserves the
            right to correct any errors or mistakes made by the Payment
            Processor even if the Payment Processor has already requested or
            received payment. Depending on your Payment Method, certain terms
            related to your payment may be set forth in agreements between you
            and your bank, financial institution, credit card issuer or other
            provider of your chosen Payment Method. If Inner Balance does not
            receive payment from you through the Payment Processor when due, you
            agree to pay all amounts due on your Billing Account upon demand.
            You must provide current, complete and accurate information for your
            Billing Account and promptly update all information to keep your
            Billing Account current, complete and accurate (such as a change in
            billing address, credit card number, or credit card expiration
            date). If you do not maintain accurate Billing Account information
            then Inner Balance may continue charging you for any use of the
            Program under your Billing Account up and until this Agreement and
            your Program is terminated.
          </p>
        </div>
        <div className="flex items-start gap-3 mt-6">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins sm:text-base text-sm">
            Subscription Fees are due in a single sum in advance on a monthly
            basis.
          </p>
        </div>
        <div className="flex items-start gap-3 mt-6">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins sm:text-base text-sm">
            Some Subscription Options may consist of an initial period, for
            which there is a one-time charge, followed by recurring periodic
            charges. By choosing a recurring payment plan, you acknowledge that
            such Subscription Option has an initial and recurring payment
            feature and you accept responsibility for all recurring charges that
            you agreed to when purchasing your Program. You shall remain
            responsible for all applicable recurring charges in the event that
            your Program is terminated prior to its completion
          </p>
        </div>
        <h4 className="mt-8 font-montserrat text-xl font-semibold text-header-bg">
          2. No Emergency Care; Certain Services and Items Excluded.
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          Inner Balance does not provide any urgent or emergency care services.
          If you ever have an urgent care need or medical emergency while
          participating, you must dial 911. Inner Balance does not provide
          urgent care or treat medical emergencies nor does Inner Balance offer
          or provide primary care services, or dispense any medications.
        </p>
        <h4 className="mt-8 font-montserrat text-xl font-semibold text-header-bg">
          3. Direct Health Care Service.
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          Inner Balance consists of a direct health care service; for clarity,
          it is not health insurance. Inner Balance does not participate with or
          bill commercial health insurance plans or federal health care programs
          such as Medicare or Medicaid. Your Provider(s) may recommend that you
          receive services not offered by the Practices (such as, for example,
          specialty services or diagnostic tests), but in no event will any
          Practice be responsible for any resulting medical bills or otherwise.
          If you have health insurance, your health insurance policy is a
          contract between you and your insurance company. It is your
          responsibility to know your benefits, and how they will apply to your
          benefit payments. Inner Balance assumes no responsibility to
          understand or be bound by the terms and conditions of any insurance
          plan or program. There is no guarantee that your insurance company
          will make any payment on or otherwise reimburse in any manner any fees
          or other costs or expenses you incur in connection with Inner Balance
          or any other services you may have purchased.
        </p>
        <h4 className="mt-8 font-montserrat text-xl font-semibold text-header-bg">
          4. Prescriptions.
        </h4>
        <div className="flex items-start gap-3 mt-6">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins sm:text-base text-sm">
            An Inner Balance provider may prescribe certain medication(s) for
            you, the cost of any such medication is included in your
            Subscription Fees.
          </p>
        </div>
        <div className="flex items-start gap-3 mt-6">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins sm:text-base text-sm">
            If a Provider prescribes hormone therapy, the Provider may limit to
            a specific type such as bio-identical hormones only, limit to a
            specific pharmacy, or pharmacologic product based on supply,
            quality, consistency of product, good clinical practice and/or state
            regulations. Compounding pharmacies vary in their quality and
            availability. Any medication orders will be based on the Provider’s
            informed medical judgment, the circumstances of the situation and
            best interests of the member. Inner Balance does not guarantee that
            any prescriptions will be ordered as part of your Program and/or
            through the Services. Providers will at all times exercise
            professional discretion and reserve the right to deny care and/or
            cancel any prescription due to actual or potential misuse of the
            Services.
          </p>
        </div>
        <div className="flex items-start gap-3 mt-6">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins sm:text-base text-sm">
            You agree that any prescriptions that you receive from a Provider
            are solely for your personal use and you will not share or
            distribute any medication to any other person. You agree to fully
            and carefully read all provided medication information and labels
            and to contact an Inner Balance physician or pharmacist with any
            questions about your medication. Inner Balance and the Providers
            fully honor patient freedom of choice and if you receive a
            prescription for a medication, you have the right to have any
            prescription sent to the pharmacy of your choice. If you choose to
            have your prescription fulfilled at a pharmacy of your choosing,
            then Inner Balance reserves the right to charge an additional
            processing fee.
          </p>
        </div>
        <div className="flex items-start gap-3 mt-6">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins sm:text-base text-sm">
            Finally, you agree and provide consent for Inner Balance’s pharmacy
            partners to contact you, including by SMS message, email and/or via
            the use of an automatic telephone dialing system, artificial voice,
            and/or prerecorded messages, for purposes of providing pharmacy
            services to you.
          </p>
        </div>
        <h4 className="mt-8 font-montserrat text-xl font-semibold text-header-bg">
          5. Use of medication.
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          Following your purchase of a subscription and upon receipt of your
          initial welcome package, you agree to review the educational materials
          provided and reach out to customer service with any questions. You
          understand and agree that Inner Balance may modify or remove
          components of your Prescription and may suspend and/or terminate
          subscription if you fail to comply with any of the requirements set
          forth in this Agreement.
        </p>
        <h4 className="mt-8 font-montserrat text-xl font-semibold text-header-bg">
          6. Term and Termination.
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          Term. Inner Balance may, in its sole discretion, not accept this
          Agreement and return your Subscription Fees to you. If Inner Balance
          accepts this Agreement, then the term of the Agreement will begin on
          the date Inner Balance receives your Subscription Fees and lasts for
          the length of the subscription you purchased (the “Term”) unless
          terminated sooner by either party. Termination. You may terminate this
          Agreement and your participation in the Program at any time by
          contacting subscriptions@innerbalance.com. Upon termination, you may
          be eligible for a refund as set forth in our Refund Policy, which is
          incorporated herein by reference. Inner Balance may terminate this
          Agreement and your Subscription, and/or modify or remove components of
          your Subscription at any time, if you fail to comply with this
          Agreement. In that event, you will not be eligible for any refund.
        </p>
        <h4 className="mt-8 font-montserrat text-xl font-semibold text-header-bg">
          7. Entire Agreement; Amendment.
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          This Agreement sets forth the entire agreement between the parties
          regarding the subject matter hereof and supersedes all prior or
          contemporaneous oral or written agreements. Inner Balance reserves the
          right to change this Agreement at any time by providing prior notice
          through the Services and/or by sending an email to your email address
          of record. Notwithstanding the preceding, Inner Balance agrees that it
          will not change any provisions related to your Subscription Fees
          retroactively. If you do not agree with the updated Agreement, you may
          reject it by emailing subscriptions@innerbalance.com; if you reject
          the updated Agreement, you will no longer be able to use or otherwise
          participate and your ability to obtain a refund shall be subject to
          our Refund Policy. If you continue to use or otherwise participate in
          the Program in any way after a change to this Agreement takes effect,
          that means you agree to the updated Agreement. Except for changes as
          described herein, no other amendment or modification of this Agreement
          will be effective unless in writing and signed by both parties.
        </p>
      </div>
    </>
  );
};

export default TermsAndConditions;

import React, { ReactNode } from "react";
import Header from "../Global/Header";
import Footer from "../Global/Footer";
import { Helmet } from "react-helmet";


type Props = {
  children?: ReactNode;
  title?: string;
  home?: boolean;
};

const MainLayout = ({
  children,
  title = "DealFusion",
}: Props) => (
  <div>
     <Helmet>
        <title>{title}</title>
      </Helmet>
    <Header />
    <main className="min-h-screen">{children}</main>
    <Footer/>
  </div>
);

export default MainLayout;
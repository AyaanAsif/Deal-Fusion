import React from "react";
import { trendingStores } from "../../Mock/AllStoresMock";
import { Link } from "react-router-dom";

const TrendingStores: React.FC = () => {

    const trendingStoresData = trendingStores;

    const renderTrendingStoresData = trendingStoresData.map(
        (item: any, index: number) => {
            return (
                <React.Fragment key={`${item.id}${index}`}>
                <Link to="/store-details">
                <div>
                <div className="border border-gray-500 rounded-tr-xl rounded-bl-xl h-32 w-32 flex items-center justify-center cursor-pointer">
                  <img src={item.storeLogo} alt="" className="w-20" />
                </div>
                <h1 className="font-montserrat text-base font-semibold text-center mt-3 cursor-pointer">{item.storeName}</h1>
                </div>
                </Link>
                </React.Fragment>
            )
        }
    )
  return (
    <>
      <div className="py-14">
        <h1 className="font-montserrat font-bold xl:text-4xl md:text-3xl text-2xl text-header-bg text-center">
          Newly Listed & Trending Stores
        </h1>
        <div className="grid lg:grid-cols-6 sm:grid-cols-4 grid-cols-2 gap-y-5 mt-14 justify-items-center">{renderTrendingStoresData}</div>
      </div>
    </>
  );
};

export default TrendingStores;

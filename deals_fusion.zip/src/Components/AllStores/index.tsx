import React, { useState, useEffect } from "react";
import { selectPopularStores } from "../../Mock/AllStoresMock";
import TrendingStores from "./TrendingStores";

const AllStores: React.FC = () => {
  const [perAlpha, setPerAlpha] = useState<string | undefined>();

  useEffect(() => {
    // Set the initial value of perAlpha to the first item when the component mounts
    setPerAlpha(selectPopularStores[0]?.itemName);
  }, []);

  // const renderingAlpha = selectPopularStores.map((perValue: any) => (
  //   <div
  //     className="perAlpha hover:bg-primary hover:text-white h-10 lg:w-20 w-16 flex justify-center items-center cursor-pointer"
  //     onClick={() => settingAlpha(perValue.itemName)}
  //     key={perValue.id}
  //   >
  //     {perValue.itemName}
  //   </div>
  // ));
  const renderingAlpha = selectPopularStores.map((perValue: any) => (
    <div
      className={`perAlpha hover:bg-header-bg hover:text-white h-10 lg:w-20 w-16 flex justify-center items-center cursor-pointer ${
        perValue.itemName === perAlpha ? "bg-header-bg text-white" : ""
      }`}
      onClick={() => settingAlpha(perValue.itemName)}
      key={perValue.id}
    >
      {perValue.itemName}
    </div>
  ));

  const settingAlpha = (itemName: string) => {
    setPerAlpha(itemName);
  };

  const findingDataFromStore = selectPopularStores.find(
    (perValue: any) => perValue.itemName === perAlpha
  );

  const renderingDataFromStore = findingDataFromStore?.itemDetails.map(
    (perValue: string, index: number) => (
      <div
        className="perData font-montserrat font-medium text-gray-700"
        key={index}
      >
        <h3>{perValue}</h3>
      </div>
    )
  );

  return (
    <>
      <div className="2xl:container mx-auto xl:px-20 lg:px-10 px-5 pb-20">
        <TrendingStores />
        <h1 className="font-montserrat font-bold xl:text-4xl md:text-3xl text-2xl text-header-bg text-center">
        Top Merchants
        </h1>
        <div className="alphaBar flex lg:flex-nowrap flex-wrap uppercase border border-gray-400 font-semibold lg:px-10 sm:px-5 px-3 sm:rounded-[50px] mt-8">
          {renderingAlpha}
        </div>
        <div className="renderingStoreData mt-10 space-y-2 grid md:grid-cols-5 sm:grid-cols-3 grid-cols-2 justify-items-center">
          {renderingDataFromStore}
        </div>
      </div>
    </>
  );
};

export default AllStores;

import React, { useState } from "react";
import { Link } from "react-router-dom";

const Login: React.FC = () => {
  return (
    <div className="flex items-center h-screen bg-gray-100">
      <div className="grid md:grid-cols-2 grid-cols-1 2xl:container mx-auto xl:px-20 lg:px-10 px-5 h-11/12">
        <div className="p-6 md:rounded-tl-3xl md:rounded-bl-3xl rounded-2xl bg-white xl:py-6 py-16 relative">
        <Link to="/">
            <img
              src="/images/logo-blue.png"
              alt=""
              className="absolute top-5 left-5 cursor-pointer"
            />
          </Link>
          <div className="flex items-center justify-center w-full h-full">
            <div className="flex flex-col items-center justify-center h-full">
              <div>
                <h2 className="text-header-bg font-montserrat lg:text-3xl md:text-2xl text-xl font-semibold sm:mt-0 mt-5">
                  Login To Your Account
                </h2>
                <p className="text-light-blue font-poppins text-sm mt-3">
                  Welcome back! Please enter your details.
                </p>
                <p className="mt-6 text-header-bg font-poppins text-sm font-medium">
                  Email
                </p>
                <input
                  type="text"
                  placeholder="Enter your email"
                  className="w-full border border-gray-400 rounded-tr-xl rounded-bl-xl mt-2 h-12 px-2 font-montserrat"
                />
                <p className="mt-6 text-header-bg font-poppins text-sm font-medium">
                  Password
                </p>
                <input
                  type="password"
                  placeholder="Enter your password"
                  className="w-full border border-gray-400 rounded-tr-xl rounded-bl-xl mt-2 h-12 px-2 font-montserrat"
                />
                <div className="mt-5 flex md:flex-row flex-col items-center justify-between">
                  <div className="flex items-center gap-2">
                    <input type="checkbox" />
                    <p className="text-light-blue font-poppins text-sm font-medium">
                      Remember for 30 days
                    </p>
                  </div>
                  <Link to="/forgot-password">
                    <p className="text-header-bg font-poppins text-sm font-medium md:mt-0 mt-4 md:text-start text-center">
                      Fotgot Password?
                    </p>
                  </Link>
                </div>
                <button className="mt-5 button w-full">Sign in</button>
                <button className="mt-5 w-full border border-gray-500 gradient-text flex items-center justify-center h-12 rounded-tr-lg rounded-bl-lg font-medium text-base font-poppins">
                  Continue with Google
                </button>
                <p className="text-light-blue font-poppins text-sm font-medium mt-6 text-center">
                  Don't have an account?{" "}
                  <Link to="/register">
                    <span className="text-[#243763]">Sign up</span>
                  </Link>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="md:grid hidden grid-cols-2 bg-white">
          <div className="lg:flex hidden items-center z-40 col-span-1">
            <img
              src="/images/log-in/img-2.png"
              alt=""
              className="ml-[100px] lg:block hidden"
            />
          </div>
          <div className="lg:col-span-1 col-span-2 relative flex justify-center items-center w-full">
            <img
              src="/images/log-in/img-1.png"
              alt=""
              className="h-full w-full rounded-tr-3xl rounded-br-3xl"
            />
            <img
              src="/images/log-in/img-2.png"
              alt=""
              className="absolute lg:hidden block w-72"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;

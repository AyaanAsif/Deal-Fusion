import React, { useState } from "react";
import { selectCategories } from "../../Mock/CategoriesMock";
import { Link } from "react-router-dom";
import * as Icons from "../../Components/Global/Icons"
import {
  storeDescription,
  storeDetailsData,
} from "../../Mock/StoreDetailsMock";

const Coupons: React.FC = () => {
  const [showHover, setShowHover] = useState<boolean>(false);
  const [showPopup, setShowPopup] = useState<boolean>(false);

  const storeDetailsMockData: any = storeDetailsData;
  const storeDescriptionData: any = storeDescription;

  const renderStoreDetialsData = storeDetailsMockData.map(
    (item: any, index: number) => {
      return (
        <React.Fragment key={`${item.id}${index}`}>
          <div className="w-full rounded-tr-2xl">
            <div className="w-full border border-[#DDE1EB] sm:rounded-[2px_16px] rounded-lg flex sm:flex-row flex-col items-center justify-between gap-3 h-full overflow-hidden bg-white">
              <div className="flex gap-3 items-center sm:px-4 px-4 sm:py-5 py-3">
                <div className="sm:h-24 sm:w-28 bg-[#F6F7FB] rounded-md sm:flex hidden flex-col justify-center items-center">
                  <p className="text-center font-montserrat sm:text-2xl text-lg font-bold text-[#243763] uppercase">
                    {item.discount[0]}
                  </p>
                  <p className="text-center font-montserrat text-xs font-semibold text-[#243763] uppercase">
                    {item.discount[1]}
                  </p>
                </div>
                <div className="">
                  <p className="sm:text-sm text-xs  gradient-text font-poppins font-semibold uppercase">
                    {item.couponType === "Show Code" ? "Code" : "Sale"}
                  </p>
                  <h1 className="font-montserrat xl:text-xl sm:text-lg text-base font-semibold text-[#16213B]">
                    {item.couponHeading}
                  </h1>
                  <p className="sm:text-sm text-xs  text-[#A0A8BE] font-poppins font-medium mt-2">
                    {item.couponDates}
                  </p>
                </div>
                <div className="sm:hidden">
                  <Icons.rightArrowIconMob />
                </div>
              </div>
              <div className="w-20 h-[9.2rem] sm:flex hidden flex-col items-center gap-3">
                <div className="h-1/4 w-full bg-[#F6F7FB] card-top"></div>
                <div className="h-3/5 w-1 border-l-2 border-dashed border-[#DDE1EB]"></div>
                <div className="h-1/4 w-full bg-[#F6F7FB] card-bottom"></div>
              </div>
              <div className="w-56 px-4 py-5 sm:block hidden">
                {item.couponType === "Show Code" ? (
                  <button
                    onClick={() => setShowPopup(true)}
                    onMouseEnter={() => setShowHover(true)}
                    onMouseLeave={() => setShowHover(false)}
                    className="code-main"
                  >
                    <div className="inner-btn">{item.couponCode}</div>
                    <div
                      className={`outer-btn ${
                        showHover ? "w-[154px]" : "w-[164px]"
                      }`}
                    >
                      {item.couponType}
                    </div>
                    <div
                      className={`absolute top-0 transition-all ease-in-out duration-500 ${
                        showHover ? "right-2" : "right-0"
                      }`}
                    >
                      <Icons.CouponUpperElement />
                    </div>
                  </button>
                ) : (
                  <button className="button">{item.couponType}</button>
                )}
              </div>
            </div>
          </div>
        </React.Fragment>
      );
    }
  );

  return (
    <>
      <div className="h-28 flex items-center bg-gray-100">
        <div className="2xl:container mx-auto xl:px-20 lg:px-10 px-5">
          <h1 className="font-montserrat text-4xl font-bold text-header-bg">
            Featured Coupon Codes
          </h1>
        </div>
      </div>
      <div className="2xl:container mx-auto xl:px-20 lg:px-10 px-5 flex flex-col items -between">
      <div className="my-10 space-y-4">{renderStoreDetialsData}</div>
      </div>
    </>
  );
};

export default Coupons;

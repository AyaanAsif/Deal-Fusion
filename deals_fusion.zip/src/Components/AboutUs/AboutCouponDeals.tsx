import React from "react";

const AboutCouponDeals: React.FC = () => {
  return (
    <>
      <div className="py-10 grid sm:grid-cols-2 grid-cols-1 lg:gap-24 gap-10">
        <div className="flex sm:flex-col flex-col-reverse">
          <div className="sm:mt-0 mt-8">
          <h2 className="text-header-bg font-montserrat lg:text-4xl text-2xl font-semibold">
            About Coupon Deals
          </h2>
          <p className="mt-3 text-light-blue font-poppins text-base font-normal">
            Welcome to Coupon Deals, your ultimate destination for unbeatable
            coupon codes, cashback offers, and exclusive deals!{" "}
          </p>
          <p className="mt-5 text-light-blue font-poppins text-base font-normal">
            We are passionate about helping you save money and make smart
            purchasing decisions, and our website is designed to simplify your
            shopping experience. With a wide range of carefully curated deals
            from leading brands and retailers, we aim to be your go-to platform
            for finding the best discounts on the products you love.{" "}
          </p>
          </div>
          <img src="/images/about/img-2.png" alt="" className="w-auto mt-10" />
        </div>
        <div>
          <img src="/images/about/img-1.png" alt="" className="w-auto" />
          <p className="mt-10 text-light-blue font-poppins text-base font-normal">
            Our dedicated team scours the web to find the latest and most
            lucrative deals, ensuring that you never miss out on significant
            savings.{" "}
          </p>
          <button className="button mt-8">Contact Us</button>
        </div>
      </div>
    </>
  );
};

export default AboutCouponDeals;

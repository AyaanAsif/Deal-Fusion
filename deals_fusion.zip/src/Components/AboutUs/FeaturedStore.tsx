import React from "react";
import Slider from "react-slick";

const featuredStores = [
  {
    id: 1,
    storeImage: "/images/featured-stores/img-1.png",
  },
  {
    id: 2,
    storeImage: "/images/featured-stores/img-2.png",
  },
  {
    id: 3,
    storeImage: "/images/featured-stores/img-3.png",
  },
  {
    id: 4,
    storeImage: "/images/featured-stores/img-4.png",
  },
  {
    id: 5,
    storeImage: "/images/featured-stores/img-5.png",
  },
  {
    id: 6,
    storeImage: "/images/featured-stores/img-6.png",
  },
  {
    id: 7,
    storeImage: "/images/featured-stores/img-4.png",
  },
  {
    id: 8,
    storeImage: "/images/featured-stores/img-5.png",
  },
  {
    id: 9,
    storeImage: "/images/featured-stores/img-6.png",
  },
];

const FeaturedStore: React.FC = () => {
  var settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 6,
    slidesToScroll: 2,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 2,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 2,
          initialSlide: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
    ],
  };

  const renderFeaturedStores = featuredStores.map(
    (item: any, index: number) => {
      return (
        <React.Fragment key={`${item.id}${index}`}>
          <div>
            <img src={item.storeImage} alt="" />
          </div>
        </React.Fragment>
      );
    }
  );

  return (
    <>
      <Slider {...settings}>{renderFeaturedStores}</Slider>
    </>
  );
};

export default FeaturedStore;

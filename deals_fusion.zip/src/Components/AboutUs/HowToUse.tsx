import React from "react";
import FeaturedStore from "./FeaturedStore";

const howToUseCoupons = [
  {
    id: 1,
    cardIcon: "/images/how-to-use/img-1.png",
    cardHeading: "Tap the Offers(s) You Like",
    cardDescription:
      "Tap the Offer You Like, You will see the coupon code displayed on the coupon and use it.",
  },
  {
    id: 2,
    cardIcon: "/images/how-to-use/img-2.png",
    cardHeading: "Copy Code",
    cardDescription:
      "At curbside pickup, you can use it simply by telling the coupon code before making a payment.",
  },
  {
    id: 3,
    cardIcon: "/images/how-to-use/img-3.png",
    cardHeading: "Paste Code",
    cardDescription:
      "Make sure to copy the coupon code and paste it before you complete your order while shopping online.",
  },
];

const HowToUse: React.FC = () => {
  const renderHowToUseCoupons = howToUseCoupons.map(
    (item: any, index: number) => {
      return (
        <React.Fragment key={`${item.id}${index}`}>
          <div className="border border-[#DDE1EB] rounded-[2px_24px] py-8 px-5 h-72 flex flex-col items-center bg-white">
            <img src={item.cardIcon} alt="" />
            <h1 className="mt-3 font-montserrat font-semibold text-xl text-header-bg text-center">
              {item.cardHeading}
            </h1>
            <p className="mt-3 font-poppins text-sm font-normal text-light-blue text-center">
              {item.cardDescription}
            </p>
          </div>
        </React.Fragment>
      );
    }
  );

  return (
    <>
      <div className="py-20">
        <h2 className="font-montserrat lg:text-4xl text-2xl font-semibold text-header-bg text-center">
          How To Use Coupons
        </h2>
        <div className="grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 sm:gap-10 gap-6 mt-12">
          {renderHowToUseCoupons}
        </div>
      </div>
      <div className="w-full h-[1px] bg-gray-300 m-auto"></div>
      <div className="py-20">
        <h2 className="font-montserrat lg:text-4xl text-2xl font-semibold text-header-bg text-center">
          Coupon Deals Has Been Proudly Featured On...
        </h2>
        <div className="mt-10">
          <FeaturedStore />
        </div>
      </div>
    </>
  );
};

export default HowToUse;

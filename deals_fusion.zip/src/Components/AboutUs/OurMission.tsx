import React from "react";

const OurMission: React.FC = () => {
  return (
    <>
      <div className="pt-20 pb-10 flex sm:flex-row flex-col-reverse lg:gap-24 gap-10 items-center">
        <div className="sm:w-1/2 w-full">
          <h2 className="text-header-bg font-montserrat lg:text-4xl text-2xl font-semibold">
            Our Mission & Vision
          </h2>
          <p className="mt-3 text-light-blue font-poppins text-base font-normal">
            Coupons, cashback, and deals work as powerful tools to help
            consumers save money and get the best value for their purchases.
          </p>
          <div className="mt-6 flex lg:flex-row flex-col gap-8">
            <div>
              <div className="flex items-center gap-3">
                <img src="/images/about/img-4.png" alt="" />
                <p className="font-montserrat font-semibold text-xl text-header-bg">
                  Our Mission
                </p>
              </div>
              <p className="mt-5 text-light-blue font-poppins text-sm font-normal">
                To empower consumers with the best coupon codes, cashback
                offers, and exclusive deals, helping them save money and make
                wise purchasing decisions effortlessly.
              </p>
            </div>
            <div>
              <div className="flex items-center gap-3">
                <img src="/images/about/img-5.png" alt="" />
                <p className="font-montserrat font-semibold text-xl text-header-bg">
                  Our Vision
                </p>
              </div>
              <p className="mt-5 text-light-blue font-poppins text-sm font-normal">
                To become the leading platform that connects savvy shoppers with
                unparalleled savings opportunities, revolutionizing the way
                people shop and save.
              </p>
            </div>
          </div>

          <button className="button mt-8">Contact Us</button>
        </div>
        <div>
          <img src="/images/about/img-3.png" alt="" className="w-auto" />
        </div>
      </div>
    </>
  );
};

export default OurMission;

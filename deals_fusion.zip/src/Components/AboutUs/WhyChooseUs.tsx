import React from "react";
import * as Icons from "../Global/Icons";

const WhyChooseUs: React.FC = () => {
  return (
    <>
      <div className="flex sm:flex-row flex-col gap-10 py-20">
        <div className="sm:w-1/2 w-full">
          <h1 className="font-montserrat lg:text-4xl text-2xl font-semibold text-header-bg">
            Why Choose Us
          </h1>
          <p className="lg:text-base text-sm font-poppins text-light-blue font-normal mt-10">
            We curate the best coupons, cashback offers, and deals, ensuring our
            users can save money and make the most out of every purchase.
          </p>
          <div className="mt-5">
            <p className="lg:text-base text-sm font-poppins text-light-blue font-normal mt-3 flex gap-3">
              <span className="mt-1">
                <Icons.chooseBulletIcon />
              </span>
              Coupons are promotional codes or vouchers that provide discounts
              on products or services. When shopping online or in-store, users
              can apply these codes during checkout to avail of the specified
              discount.
            </p>
            <p className="lg:text-base text-sm font-poppins text-light-blue font-normal mt-5 flex gap-3">
              <span className="mt-1">
                <Icons.chooseBulletIcon />
              </span>
              Cashback is a form of reward where users receive a percentage of
              the purchase amount back as cash after making a qualifying
              transaction. To avail cashback, shoppers must access the
              retailer's website through a cashback platform or link.
            </p>
            <p className="text-base font-poppins text-light-blue font-normal mt-5 flex gap-3">
              <span className="mt-1">
                <Icons.chooseBulletIcon />
              </span>
              Deals refer to special offers or discounts on products or services
              provided directly by retailers or brands. These deals can include
              limited-time promotions, buy-one-get-one-free offers, clearance
              sales, and more.
            </p>
            <div className="button w-56 mt-8 cursor-pointer">
              Browse Cashback Offer{" "}
            </div>
          </div>
        </div>
        <div className="sm:w-1/2 w-full grid lg:grid-cols-2 grid-cols-1 gap-8">
          <div className="rounded-[0px_24px] border border-[#DDE1EB] py-6 px-5 flex flex-col items-center justify-center ">
            <img src="/svgs/customer-icon.svg" alt="" />
            <h2 className="text-header-bg font-montserrat text-3xl font-semibold mt-3">
              5000+
            </h2>
            <p className="mt-2 text-light-blue font-poppins text-base font-medium uppercase">
              Happy Customers
            </p>
          </div>
          <div className="rounded-[0px_24px] border border-[#DDE1EB] py-6 px-5 flex flex-col items-center justify-center">
            <img src="/svgs/active-coupons-icon.svg" alt="" />
            <h2 className="text-header-bg font-montserrat text-3xl font-semibold mt-3">
              5000+
            </h2>
            <p className="mt-2 text-light-blue font-poppins text-base font-medium uppercase">
              Active Coupons
            </p>
          </div>
          <div className="rounded-[0px_24px] border border-[#DDE1EB] py-6 px-5 flex flex-col items-center justify-center">
            <img src="/svgs/cashback-offers-icon.svg" alt="" />
            <h2 className="text-header-bg font-montserrat text-3xl font-semibold mt-3">
              5000+
            </h2>
            <p className="mt-2 text-light-blue font-poppins text-base font-medium uppercase">
              Cashback Offers
            </p>
          </div>
          <div className="rounded-[0px_24px] border border-[#DDE1EB] py-6 px-5 flex flex-col items-center justify-center">
            <img src="/svgs/trending-deals-icon.svg" alt="" />
            <h2 className="text-header-bg font-montserrat text-3xl font-semibold mt-3">
              5000+
            </h2>
            <p className="mt-2 text-light-blue font-poppins text-base font-medium">
              Trending Deals
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default WhyChooseUs;

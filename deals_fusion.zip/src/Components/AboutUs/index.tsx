import React from "react";
import AboutCouponDeals from "./AboutCouponDeals";
import OurMission from "./OurMission";
import HowToUse from "./HowToUse";
import WhyChooseUs from "./WhyChooseUs";
import CustomerFeedback from "./CustomerFeedback";

const AboutUs: React.FC = () => {
  return (
    <>
      <div className="inner-banner flex justify-center items-center">
        <h1 className="font-montserrat text-3xl font-semibold text-white">
          About Us
        </h1>
      </div>
        <div className="pt-10 2xl:container mx-auto 2xl:px-40 xl:px-20 lg:px-10 px-5">
          <AboutCouponDeals/>
          <OurMission/>
        </div>
        <div className="bg-[#FBFCFD]">
          <div className="2xl:container mx-auto 2xl:px-40 xl:px-20 lg:px-10 px-5">
          <HowToUse/>
          <WhyChooseUs/>
          <CustomerFeedback/>
          </div>
        </div>
    </>
  );
};

export default AboutUs;

import React from "react";
import Slider from "react-slick";

const reviewData = [
  {
    id: 1,
    reviewDescription:
      "I recently purchased online coupon bundles from this website, The variety and value of the coupons were outstanding, allowing me to save a significant amount on my favorite products and services. I highly recommend this website for anyone looking to enjoy fantastic savings and a delightful shopping experience!",
    reviewAuthor: "Roger Mavrides",
    reviewerPosition: "Testo USA, Product Manager",
  },
  {
    id: 2,
    reviewDescription:
      "I recently purchased online coupon bundles from this website, The variety and value of the coupons were outstanding, allowing me to save a significant amount on my favorite products and services. I highly recommend this website for anyone looking to enjoy fantastic savings and a delightful shopping experience!",
    reviewAuthor: "Roger Mavrides",
    reviewerPosition: "Testo USA, Product Manager",
  },
  {
    id: 3,
    reviewDescription:
      "I recently purchased online coupon bundles from this website, The variety and value of the coupons were outstanding, allowing me to save a significant amount on my favorite products and services. I highly recommend this website for anyone looking to enjoy fantastic savings and a delightful shopping experience!",
    reviewAuthor: "Roger Mavrides",
    reviewerPosition: "Testo USA, Product Manager",
  },
];

const CustomerFeedback: React.FC = () => {
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1
      };

  const renderReviewData = reviewData.map((item: any, index: number) => {
    return (
      <React.Fragment key={`${item.id}${index}`}>
        <div>
          <p className="text-light-blue font-poppins text-base font-normal">
            {item.reviewDescription}
          </p>
          <h3 className="mt-4 text-header-bg font-montserrat text-xl font-semibold">
            {item.reviewAuthor}
          </h3>
          <p className="mt-2 text-light-blue font-poppins text-base font-normal">
            {item.reviewerPosition}
          </p>
        </div>
      </React.Fragment>
    );
  });
  return (
    <>
      <div className="flex sm:flex-row flex-col-reverse lg:gap-20 gap-10 py-20">
        <div className="sm:w-1/2 w-full">
          <h2 className="text-header-bg font-montserrat lg:text-4xl text-2xl font-semibold">
            What Our Customer Are Saying
          </h2>
          <img src="/svgs/review-icons.svg" alt="" className="mt-6" />
          <div className="mt-8">
            <Slider {...settings}>
                {renderReviewData}
            </Slider>
          </div>
        </div>
        <div className="sm:w-1/2 w-full">
            <img src="/images/customer-review/img-1.png" alt="" />
        </div>
      </div>
    </>
  );
};

export default CustomerFeedback;

import React from "react";
import { BlogMock } from "../../Mock/BlogsMock";
import * as Icons from "../Global/Icons";
import { Link } from "react-router-dom";

const Blogs: React.FC = () => {
  const blogsMockData = BlogMock;

  const renderBlogsMockData = blogsMockData.map((item: any, index: number) => {
    return (
      <React.Fragment key={`${item.id}${index}`}>
        <Link to="/blog-details">
        <div className="rounded-md">
          <img src={item.blogImage} alt="" className="w-full object-cover" />
          <div className="px-5 py-5 border border-gray-300 bg-[#F8F8F8]">
            <div className="w-32 py-1 bg-secondary text-white font-poppins xl:text-base text-sm font-semibold flex items-center justify-center">
              {item.blogPreHeading}
            </div>
            <h1 className="xl:text-2xl text-lg font-montserrat font-medium mt-3">
              {item.blogHeading}
            </h1>
            <div className="mt-8 flex items-center justify-between text-sm">
              <p>{item.blogAuthor}</p>
              <div className="flex items-center gap-2">
                <Icons.watchIcon />
                <p className="text-xs text-gray-500">{item.blogPostTime}</p>
              </div>
            </div>
          </div>
        </div>
        </Link>
      </React.Fragment>
    );
  });
  return (
    <>
      <div className="inner-banner flex justify-center items-center">
        <h1 className="font-montserrat sm:text-3xl text-xl font-semibold text-white">
          Our Blogs
        </h1>
      </div>
      <div className="2xl:container mx-auto 2xl:px-40 xl:px-20 lg:px-10 px-5 py-20 grid lg:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-10">{renderBlogsMockData}</div>
    </>
  );
};

export default Blogs;

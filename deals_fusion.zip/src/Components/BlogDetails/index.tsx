import React from "react";

const BlogDetails: React.FC = () => {
  return (
    <>
      <div className="inner-banner flex justify-center items-center">
        <h1 className="font-montserrat text-3xl font-semibold text-white">
          Blog Details
        </h1>
      </div>
      <div className="2xl:container mx-auto xl:px-20 lg:px-10 px-5 py-20">
        <h2 className="font-montserrat text-3xl font-bold">
          Dolor sit amet consectetur adipisicing elit
        </h2>
        <p className="text-base font-montserrat mt-5">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore ipsum
          vel dignissimos blanditiis tenetur! Commodi, ad mollitia odio illum
          suscipit nostrum blanditiis maxime animi voluptatum maiores earum
          officiis fugiat illo, voluptatem magni. Maiores voluptatem alias
          quibusdam debitis earum dolore soluta fugit aut ab fuga. At obcaecati
          quae pariatur harum corrupti voluptas distinctio debitis laudantium.
          Libero, enim. Tenetur? Lorem ipsum dolor sit amet consectetur
          adipisicing elit. Tempore ipsum vel dignissimos blanditiis tenetur!
          Commodi, ad mollitia odio illum suscipit nostrum blanditiis maxime
          animi voluptatum maiores earum officiis fugiat illo, voluptatem magni.
          Maiores voluptatem alias quibusdam debitis earum dolore soluta fugit
          aut ab fuga. At obcaecati quae pariatur harum corrupti voluptas
          distinctio debitis laudantium. Libero, enim. Tenetur? Lorem ipsum
          dolor sit amet consectetur adipisicing elit. Tempore ipsum vel
          dignissimos blanditiis tenetur! Commodi, ad mollitia odio illum
          suscipit nostrum blanditiis maxime animi voluptatum maiores earum
          officiis fugiat illo, voluptatem magni. Maiores voluptatem alias
          quibusdam debitis earum dolore soluta fugit aut ab fuga. At obcaecati
          quae pariatur harum corrupti voluptas distinctio debitis laudantium.
          Libero, enim. Tenetur?
        </p>
        <p className="text-base font-montserrat mt-8">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore ipsum
          vel dignissimos blanditiis tenetur! Commodi, ad mollitia odio illum
          suscipit nostrum blanditiis maxime animi voluptatum maiores earum
          officiis fugiat illo, voluptatem magni. Maiores voluptatem alias
          quibusdam debitis earum dolore soluta fugit aut ab fuga. At obcaecati
          quae pariatur harum corrupti voluptas distinctio debitis laudantium.
          Libero, enim. Tenetur? Lorem ipsum dolor sit amet consectetur
          adipisicing elit. Tempore ipsum vel dignissimos blanditiis tenetur!
          Commodi, ad mollitia odio illum suscipit nostrum blanditiis maxime
          animi voluptatum maiores earum officiis fugiat illo, voluptatem magni.
          Maiores voluptatem alias quibusdam debitis earum dolore soluta fugit
          aut ab fuga. At obcaecati quae pariatur harum corrupti voluptas
          distinctio debitis laudantium.
        </p>
        <h2 className="font-montserrat text-3xl font-bold mt-10">
          Dolor sit amet consectetur adipisicing elit
        </h2>
        <p className="text-base font-montserrat mt-5">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore ipsum
          vel dignissimos blanditiis tenetur! Commodi, ad mollitia odio illum
          suscipit nostrum blanditiis maxime animi voluptatum maiores earum
          officiis fugiat illo, voluptatem magni. Maiores voluptatem alias
          quibusdam debitis earum dolore soluta fugit aut ab fuga. At obcaecati
          quae pariatur harum corrupti voluptas distinctio debitis laudantium.
          Libero, enim. Tenetur? Lorem ipsum dolor sit amet consectetur
          adipisicing elit. Tempore ipsum vel dignissimos blanditiis tenetur!
          Commodi, ad mollitia odio illum suscipit nostrum blanditiis maxime
          animi voluptatum maiores earum officiis fugiat illo, voluptatem magni.
          Maiores voluptatem alias quibusdam debitis earum dolore soluta fugit
          aut ab fuga. At obcaecati quae pariatur harum corrupti voluptas
          distinctio debitis laudantium. Libero, enim. Tenetur? Lorem ipsum
          dolor sit amet consectetur adipisicing elit. Tempore ipsum vel
          dignissimos blanditiis tenetur! Commodi, ad mollitia odio illum
          suscipit nostrum blanditiis maxime animi voluptatum maiores earum
          officiis fugiat illo, voluptatem magni. Maiores voluptatem alias
          quibusdam debitis earum dolore soluta fugit aut ab fuga. At obcaecati
          quae pariatur harum corrupti voluptas distinctio debitis laudantium.
          Libero, enim. Tenetur?
        </p>
        <p className="text-base font-montserrat mt-8">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore ipsum
          vel dignissimos blanditiis tenetur! Commodi, ad mollitia odio illum
          suscipit nostrum blanditiis maxime animi voluptatum maiores earum
          officiis fugiat illo, voluptatem magni. Maiores voluptatem alias
          quibusdam debitis earum dolore soluta fugit aut ab fuga. At obcaecati
          quae pariatur harum corrupti voluptas distinctio debitis laudantium.
          Libero, enim. Tenetur? Lorem ipsum dolor sit amet consectetur
          adipisicing elit. Tempore ipsum vel dignissimos blanditiis tenetur!
          Commodi, ad mollitia odio illum suscipit nostrum blanditiis maxime
          animi voluptatum maiores earum officiis fugiat illo, voluptatem magni.
          Maiores voluptatem alias quibusdam debitis earum dolore soluta fugit
          aut ab fuga. At obcaecati quae pariatur harum corrupti voluptas
          distinctio debitis laudantium.
        </p>
        <h2 className="font-montserrat text-3xl font-bold mt-10">
          Dolor sit amet consectetur adipisicing elit
        </h2>
        <p className="text-base font-montserrat mt-5">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore ipsum
          vel dignissimos blanditiis tenetur! Commodi, ad mollitia odio illum
          suscipit nostrum blanditiis maxime animi voluptatum maiores earum
          officiis fugiat illo, voluptatem magni. Maiores voluptatem alias
          quibusdam debitis earum dolore soluta fugit aut ab fuga. At obcaecati
          quae pariatur harum corrupti voluptas distinctio debitis laudantium.
          Libero, enim. Tenetur? Lorem ipsum dolor sit amet consectetur
          adipisicing elit. Tempore ipsum vel dignissimos blanditiis tenetur!
          Commodi, ad mollitia odio illum suscipit nostrum blanditiis maxime
          animi voluptatum maiores earum officiis fugiat illo, voluptatem magni.
          Maiores voluptatem alias quibusdam debitis earum dolore soluta fugit
          aut ab fuga. At obcaecati quae pariatur harum corrupti voluptas
          distinctio debitis laudantium. Libero, enim. Tenetur? Lorem ipsum
          dolor sit amet consectetur adipisicing elit. Tempore ipsum vel
          dignissimos blanditiis tenetur! Commodi, ad mollitia odio illum
          suscipit nostrum blanditiis maxime animi voluptatum maiores earum
          officiis fugiat illo, voluptatem magni. Maiores voluptatem alias
          quibusdam debitis earum dolore soluta fugit aut ab fuga. At obcaecati
          quae pariatur harum corrupti voluptas distinctio debitis laudantium.
          Libero, enim. Tenetur?
        </p>
        <p className="text-base font-montserrat mt-8">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore ipsum
          vel dignissimos blanditiis tenetur! Commodi, ad mollitia odio illum
          suscipit nostrum blanditiis maxime animi voluptatum maiores earum
          officiis fugiat illo, voluptatem magni. Maiores voluptatem alias
          quibusdam debitis earum dolore soluta fugit aut ab fuga. At obcaecati
          quae pariatur harum corrupti voluptas distinctio debitis laudantium.
          Libero, enim. Tenetur? Lorem ipsum dolor sit amet consectetur
          adipisicing elit. Tempore ipsum vel dignissimos blanditiis tenetur!
          Commodi, ad mollitia odio illum suscipit nostrum blanditiis maxime
          animi voluptatum maiores earum officiis fugiat illo, voluptatem magni.
          Maiores voluptatem alias quibusdam debitis earum dolore soluta fugit
          aut ab fuga. At obcaecati quae pariatur harum corrupti voluptas
          distinctio debitis laudantium.
        </p>
      </div>
    </>
  );
};

export default BlogDetails;

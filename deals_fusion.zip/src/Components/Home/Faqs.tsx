import * as React from "react";
import Accordion from "@mui/material/Accordion";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

const Faqs = () => {
  const [expanded, setExpanded] = React.useState<string | false>(false);

  const handleChange =
    (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };

  return (
    <div className="2xl:container mx-auto lg:px-28 md:px-10 px-5 py-20">
      <h2 className="font-montserrat lg:text-4xl sm:text-2xl text-xl font-semibold">
        Frequently Asked Questions
      </h2>
      <div className="sm:my-4 h-[1px] w-full bg-white"></div>
      <Accordion
        expanded={expanded === "panel1"}
        onChange={handleChange("panel1")}
        sx={{ border: "none", boxShadow: "0px 0px red", padding: "10px 0" }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          <Typography sx={{ width: "100%", flexShrink: 0 }}>
            <p className="font-montserrat font-semibold lg:text-xl sm:text-lg text-base">
              01. How can Deals save me money when shopping online?
            </p>
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            <p className="text-light-blue font-poppins text-sm">
              Deals offers several ways for shoppers to save while shopping. We
              feature up-to-date coupon codes, free shipping offers, sales and
              promo codes for thousands of stores and restaurants. Plus, our
              cash back offers pay you to shop! Activate a cash back offer,
              shop, check out, and we'll pay you back a percentage of what you
              spent.
            </p>
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion
        expanded={expanded === "panel2"}
        onChange={handleChange("panel2")}
        sx={{ border: "none", boxShadow: "0px 0px red", padding: "10px 0" }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2bh-content"
          id="panel2bh-header"
        >
          <Typography sx={{ width: "100%", flexShrink: 0 }}>
            <p className="font-montserrat font-semibold lg:text-xl sm:text-lg text-base">
              02. How many online stores does Deals have coupons & promo codes
              for?
            </p>
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            <p className="text-light-blue font-poppins text-sm">
              Deals offers several ways for shoppers to save while shopping. We
              feature up-to-date coupon codes, free shipping offers, sales and
              promo codes for thousands of stores and restaurants. Plus, our
              cash back offers pay you to shop! Activate a cash back offer,
              shop, check out, and we'll pay you back a percentage of what you
              spent.
            </p>
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion
        expanded={expanded === "panel3"}
        onChange={handleChange("panel3")}
        sx={{ border: "none", boxShadow: "0px 0px red", padding: "10px 0" }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3bh-content"
          id="panel3bh-header"
        >
          <Typography sx={{ width: "100%", flexShrink: 0 }}>
            <p className="font-montserrat font-semibold lg:text-xl sm:text-lg text-base">
              03. Does Deals provide cash back for online purchases?
            </p>
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            <p className="text-light-blue font-poppins text-sm">
              Deals offers several ways for shoppers to save while shopping. We
              feature up-to-date coupon codes, free shipping offers, sales and
              promo codes for thousands of stores and restaurants. Plus, our
              cash back offers pay you to shop! Activate a cash back offer,
              shop, check out, and we'll pay you back a percentage of what you
              spent.
            </p>
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion
        expanded={expanded === "panel4"}
        onChange={handleChange("panel4")}
        sx={{ border: "none", boxShadow: "0px 0px red", padding: "10px 0" }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel4bh-content"
          id="panel4bh-header"
        >
          <Typography sx={{ width: "100%", flexShrink: 0 }}>
            <p className="font-montserrat font-semibold lg:text-xl sm:text-lg text-base">
              04. Does Deals have a browser extension?
            </p>
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            <p className="text-light-blue font-poppins text-sm">
              Deals offers several ways for shoppers to save while shopping. We
              feature up-to-date coupon codes, free shipping offers, sales and
              promo codes for thousands of stores and restaurants. Plus, our
              cash back offers pay you to shop! Activate a cash back offer,
              shop, check out, and we'll pay you back a percentage of what you
              spent.
            </p>
          </Typography>
        </AccordionDetails>
      </Accordion>
    </div>
  );
};

export default Faqs;

import React, { useState, useEffect } from "react";
import { selectPopularStores } from "../../Mock/AllStoresMock";
import { Link } from "react-router-dom";

const MoreStories: React.FC = () => {
  const [perAlpha, setPerAlpha] = useState<string | undefined>();

  useEffect(() => {
    // Set the initial value of perAlpha to the first item when the component mounts
    setPerAlpha(selectPopularStores[0]?.itemName);
  }, []);

  const renderingAlpha = selectPopularStores.map((perValue: any) => (
    <div
      className={`perAlpha hover:bg-secondary hover:text-white h-10 lg:w-20 w-16 flex justify-center items-center cursor-pointer ${
        perValue.itemName === perAlpha ? "bg-secondary text-white" : ""
      }`}
      onClick={() => settingAlpha(perValue.itemName)}
      key={perValue.id}
    >
      {perValue.itemName}
    </div>
  ));

  const settingAlpha = (itemName: string) => {
    setPerAlpha(itemName);
  };
  return (
    <div className="bg-blue-100">
      <div className="py-16 2xl:container mx-auto xl:px-28 sm:px-8 px-5">
        <h2 className="sm:text-3xl text-2xl font-montserrat font-semibold">
          More Stories
        </h2>
        <div className="sm:mt-8 mt-5 grid lg:grid-cols-3 grid-cols-2 sm:gap-10 gap-5">
          <div className="bg-white py-5 px-3 flex flex-col items-center justify-center border-b-4 border-header-bg">
            <img src="images/home/stories/img-1.png" alt="" className="" />
            <p className="lg:text-xl sm:text-base text-sm font-montserrat font-semibold mt-4 sm:px-5 px-1">
              50 Amazon Products That Are Worth the Hype
            </p>
          </div>
          <div className="bg-white py-5 px-3 flex flex-col items-center justify-center border-b-4 border-header-bg">
            <img src="images/home/stories/img-2.png" alt="" className="" />
            <p className="lg:text-xl sm:text-base text-sm font-montserrat font-semibold mt-4 sm:px-5 px-1">
              12 Black Friday Sneaker Deals to Shop Now
            </p>
          </div>
          <div className="bg-white py-5 px-3 flex flex-col items-center justify-center border-b-4 border-header-bg">
            <img src="images/home/stories/img-3.png" alt="" className="" />
            <p className="lg:text-xl sm:text-base text-sm font-montserrat font-semibold mt-4 sm:px-5 px-1">
              The 31 Best Black Friday Skincare Deals of 2023
            </p>
          </div>
          <div className="bg-white py-5 px-3 flex flex-col items-center justify-center border-b-4 border-header-bg">
            <img src="images/home/stories/img-4.jpg" alt="" className="" />
            <p className="lg:text-xl sm:text-base text-sm font-montserrat font-semibold mt-4 sm:px-5 px-1">
              The Best Black Friday Theragun Deals
            </p>
          </div>
          <div className="bg-white py-5 px-3 flex flex-col items-center justify-center border-b-4 border-header-bg">
            <img src="images/home/stories/img-3.png" alt="" className="" />
            <p className="lg:text-xl sm:text-base text-sm font-montserrat font-semibold mt-4 sm:px-5 px-1">
              The 31 Best Black Friday Skincare Deals of 2023
            </p>
          </div>
          <div className="bg-white py-5 px-3 flex flex-col items-center justify-center border-b-4 border-header-bg">
            <img src="images/home/stories/img-4.jpg" alt="" className="" />
            <p className="lg:text-xl sm:text-base text-sm font-montserrat font-semibold mt-4 sm:px-5 px-1">
              The Best Black Friday Theragun Deals
            </p>
          </div>
          <div className="bg-white py-5 px-3 flex flex-col items-center justify-center border-b-4 border-header-bg">
            <img src="images/home/stories/img-2.png" alt="" className="" />
            <p className="lg:text-xl sm:text-base text-sm font-montserrat font-semibold mt-4 sm:px-5 px-1">
              12 Black Friday Sneaker Deals to Shop Now
            </p>
          </div>
          <div className="bg-white py-5 px-3 flex flex-col items-center justify-center border-b-4 border-header-bg">
            <img src="images/home/stories/img-1.png" alt="" className="" />
            <p className="lg:text-xl sm:text-base text-sm font-montserrat font-semibold mt-4 sm:px-5 px-1">
              50 Amazon Products That Are Worth the Hype
            </p>
          </div>
          <div className="bg-white py-5 px-3 flex flex-col items-center justify-center border-b-4 border-header-bg">
            <img src="images/home/stories/img-3.png" alt="" className="" />
            <p className="lg:text-xl sm:text-base text-sm font-montserrat font-semibold mt-4 sm:px-5 px-1">
              The 31 Best Black Friday Skincare Deals of 2023
            </p>
          </div>
        </div>
        <div className="flex items-center justify-center">
          <Link to="">
            <button className="font-poppins text-base font-medium text-header-bg h-14 w-52 hover:bg-header-bg hover:text-white border border-header-bg rounded-[2px_24px_2px_24px] mt-10 mx-auto">
              View More
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default MoreStories;

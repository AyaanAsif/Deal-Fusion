import React from "react";
import { categoryItems } from "../../Mock/HomeMock";
import { Link } from "react-router-dom";
import Accordion from "@mui/material/Accordion";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

const CategoriesSection = () => {
  const categoriesItem = categoryItems;
  const [expanded, setExpanded] = React.useState<string | false>(false);

  const handleChange =
    (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };

  const renderCategoriesItem = categoriesItem.map(
    (item: any, index: number) => {
      return (
        <React.Fragment key={`${item.id}${index}`}>
          <div>
            <p className="font-poppins text-light-blue sm:text-base text-sm cursor-pointer hover:text-header-bg">
              {item}
            </p>
          </div>
        </React.Fragment>
      );
    }
  );
  return (
    <div className="2xl:container mx-auto lg:px-28 md:px-10 px-5 sm:pt-10 border-b border-gray-200">
      <Accordion
        expanded={expanded === "panel1"}
        onChange={handleChange("panel1")}
        sx={{ border: "none", boxShadow: "0px 0px red", padding: "10px 0" }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          <Typography sx={{ width: "100%", flexShrink: 0 }}>
            <h2 className="font-poppins sm:text-3xl text-xl font-semibold">
              Categories
            </h2>
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            <div className="grid lg:grid-cols-5 sm:grid-cols-3 grid-cols-2 gap-3 sm:mt-14 mt-6">
              {renderCategoriesItem}
            </div>
            <div className="flex items-center justify-center">
              <Link to="/categories">
                <button className="font-poppins text-base font-medium text-header-bg h-14 w-52 hover:bg-header-bg hover:text-white border border-header-bg rounded-[2px_24px_2px_24px] mt-10 mx-auto">
                  View All Categories
                </button>
              </Link>
            </div>
          </Typography>
        </AccordionDetails>
      </Accordion>
    </div>
  );
};

export default CategoriesSection;

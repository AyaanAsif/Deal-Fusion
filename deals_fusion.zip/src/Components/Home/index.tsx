import React from "react";
import Spotlight from "./Spotlight";
import MoreStories from "./MoreStories";
import TodayCoupons from "./TodayCoupons";
import CategoriesSection from "./CategoriesSection";
import PopularStores from "./PopularStores";
import Faqs from "./Faqs";

const Home: React.FC = () => {
  return (
    <>
      <div className="bg-blue-100 w-full py-10">
        <div className="flex justify-center lg:flex-nowrap flex-wrap items-center gap-5 2xl:container mx-auto xl:px-28 px-8">
          <div className="lg:w-[65%] w-full">
            <img
              src="/images/home/img-1.jpg"
              alt=""
              className="sm:h-[30rem] h-60 object-cover w-full"
            />
          </div>
          <div className="lg:h-[30rem] lg:flex hidden lg:flex-col lg:justify-between lg:w-[35%]">
            <img
              src="/images/home/img-2.png"
              alt=""
              className="lg:h-[14.5rem] h-60 w-full object-cover"
            />
            <img
              src="/images/home/img-3.jpg"
              alt=""
              className="lg:h-[14.5rem] h-60 w-full object-cover"
            />
          </div>
        </div>
      </div>

      <Spotlight/>
      <MoreStories/>
      <TodayCoupons/>
      {/* <CategoriesSection/> */}
      <PopularStores/>
      <Faqs/>
    </>
  );
};

export default Home;

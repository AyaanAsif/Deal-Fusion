import React from "react";

const Spotlight: React.FC = () => {
  return (
    <>
      <div className="py-16 2xl:container mx-auto xl:px-28 px-8">
        <h2 className="sm:text-3xl text-xl font-montserrat font-semibold">Spotlight</h2>
        <div className="mt-8 grid lg:grid-cols-4 grid-cols-2 gap-5">
          <div>
            <img
              src="images/home/img-4.jpg"
              alt=""
              className="rounded-[24px]"
            />
            <p className="sm:text-xl text-base font-montserrat font-semibold mt-4">
              Our Challanges
            </p>
          </div>
          <div>
            <img
              src="images/home/img-5.jpg"
              alt=""
              className="rounded-[24px]"
            />
            <p className="sm:text-xl text-base font-montserrat font-semibold mt-4">
              Body Language
            </p>
          </div>
          <div>
            <img
              src="images/home/img-6.png"
              alt=""
              className="rounded-[24px]"
            />
            <p className="sm:text-xl text-base font-montserrat font-semibold mt-4">
              What Happens When...
            </p>
          </div>
          <div>
            <img
              src="images/home/img-7.jpg"
              alt=""
              className="rounded-[24px]"
            />
            <p className="sm:text-xl text-base font-montserrat font-semibold mt-4">
              20-Minute Workouts
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Spotlight;

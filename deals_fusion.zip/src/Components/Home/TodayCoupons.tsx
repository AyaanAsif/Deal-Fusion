import React, { useState } from "react";
import { HomeTodaysCoupons } from "../../Mock/HomeMock";
import CouponPopup from "../Global/CouponPopup";
import * as Icons from "../Global/Icons"

const TodayCoupons: React.FC = () => {
  const [showCouponPopup, setShowCouponPopup] = useState<boolean>(false);

  const todayCouponsData = HomeTodaysCoupons;

  const renderTodaysCoupons = todayCouponsData.map(
    (item: any, index: number) => {
      return (
        <React.Fragment key={`${item.id}${index}`}>
          <div className="sm:p-3 p-2 border border-gray-200 rounded-[2px_18px_2px_18px] flex sm:flex-col flex-row items-center sm:gap-0 gap-3">
            <div className="flex items-center">
              <img
                src={item.couponImage}
                alt=""
                className="sm:w-full w-40 sm:rounded-[2px_18px_2px_18px] border border-gray-200 object-cover"
              />
            </div>
            <div>
              <div className="bg-gray-300 font-poppins font-bold text-xs w-20 mt-4 sm:flex hidden items-center justify-center h-8 rounded-lg">
                {item.couponDiscount}
              </div>
              {item.couponType === "code" ? (
                <button
                  onClick={() => setShowCouponPopup(true)}
                  className="sm:mt-8 lg:mb-0 sm:mb-4 font-poppins font-semibold lg:text-base sm:text-sm text-xs text-header-bg border-b border-header-bg border-dashed uppercase sm:hidden"
                >
                  code
                </button>
              ) : (
                <button className="sm:mt-8 lg:mb-0 sm:mb-4 font-poppins font-semibold lg:text-base sm:text-sm text-xs text-header-bg uppercase border-b border-header-bg sm:hidden">
                  deal
                </button>
              )}
              <p className="sm:text-base text-sm font-montserrat sm:font-semibold font-bold sm:mt-4">
                {item.couponHeading}
              </p>
              <p className="font-poppins text-xs font-normal text-light-purple mt-2">
                {item.couponDesc}
              </p>
              {item.couponType === "code" ? (
                <button
                  onClick={() => setShowCouponPopup(true)}
                  className="mt-5 lg:mb-0 mb-4 font-poppins font-semibold text-sm text-header-bg border-b border-header-bg border-dashed uppercase sm:block hidden"
                >
                  show coupon code
                </button>
              ) : (
                <button className="mt-5 lg:mb-0 mb-4 font-poppins font-semibold text-sm text-header-bg uppercase border-b border-header-bg sm:block hidden">
                  show deal
                </button>
              )}
              {showCouponPopup && (
                <CouponPopup
                  storeImage={item.couponImage}
                  storeHeading="Store Name"
                  storeName="Store Name"
                  closePopup={() => setShowCouponPopup(false)}
                />
              )}
            </div>
            <div className="sm:hidden">
              <Icons.rightArrowIconMob/>
            </div>
          </div>
        </React.Fragment>
      );
    }
  );
  return (
    <>
      <div className="py-16 2xl:container mx-auto xl:px-28 px-8">
        <h1 className="sm:text-3xl text-2xl font-montserrat font-semibold">
          Today's Coupons
        </h1>
        <div className="mt-10 grid 2xl:grid-cols-4 lg:grid-cols-4 sm:grid-cols-2 grid-cols-1 sm:gap-5 gap-3">
          {renderTodaysCoupons}
        </div>
      </div>
    </>
  );
};

export default TodayCoupons;

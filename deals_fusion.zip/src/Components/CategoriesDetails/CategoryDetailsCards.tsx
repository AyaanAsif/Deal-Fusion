import React, { useState } from "react";
import { CategoriesDetailsData } from "../../Mock/CategoriesDetailsMock";
import CouponPopup from "../Global/CouponPopup";
import * as Icons from "../Global/Icons";

const CategoriesDetailsCards: React.FC = () => {
  const [showCouponPopup, setShowCouponPopup] = useState<boolean>(false);

  const categoryDetailCardsData = CategoriesDetailsData;
  const renderCategoryDetails = categoryDetailCardsData.map(
    (item: any, index: number) => {
      return (
        <React.Fragment key={`${item.id}${index}`}>
          {/* <div className="xl:p-4 p-3 border border-gray-400 rounded-tr-[24px] rounded-bl-[24px] bg-white">
            <img
              src={item.categoryImage}
              alt=""
              className="w-full rounded-tr-[24px] rounded-bl-[24px]"
            />
            <div className="mt-5 bg-secondary w-16 h-6 rounded-md text-xs text-white font-medium flex justify-center items-center">
              {item.categoryDiscount}
            </div>
            <h2 className="font-montserrat xl:text-xl text-lg font-semibold text-[#16213B] mt-2">
              {item.categoryHeading}
            </h2>
            <p className="mt-2 font-poppins text-light-purple font-medium text-sm">
              {item.categoryDetail}
            </p>
            <button className="mt-8 text-primary font-poppins font-semibold text-base border-b border-dashed border-primary">
              {item.categoryType === "code" ? "Show Coupon Code" : "Show Deal"}
            </button>
          </div> */}

          <div className="lg:p-5 sm:p-2 px-2 py-3 border border-gray-200 rounded-[2px_24px_2px_24px] flex sm:flex-col flex-row items-center sm:gap-0 gap-2">
            <div className="flex items-center">
              <img
                src={item.categoryImage}
                alt=""
                className="sm:w-full w-40 sm:rounded-[2px_24px_2px_24px] border border-gray-200 object-cover"
              />
            </div>
            <div>
              <div className="bg-secondary font-poppins font-semibold text-xs text-white w-20 mt-4 sm:flex hidden items-center justify-center h-8 rounded-lg">
                {item.categoryDiscount}
              </div>
              {item.couponType === "code" ? (
                <button
                  onClick={() => setShowCouponPopup(true)}
                  className="sm:mt-8 lg:mb-0 sm:mb-4 font-poppins font-semibold lg:text-base sm:text-sm text-xs text-primary border-b border-primary border-dashed uppercase sm:hidden"
                >
                  code
                </button>
              ) : (
                <button className="sm:mt-8 lg:mb-0 sm:mb-4 font-poppins font-semibold lg:text-base sm:text-sm text-xs text-primary uppercase border-b border-primary sm:hidden">
                  deal
                </button>
              )}
              <p className="lg:text-xl sm:text-lg text-sm font-montserrat text-header-bg sm:font-semibold font-bold sm:mt-4">
                {item.categoryHeading}
              </p>
              <p className="font-poppins lg:text-sm text-xs font-normal text-light-purple mt-3">
                {item.categoryDetail}
              </p>
              {item.categoryType === "code" ? (
                <button
                  onClick={() => setShowCouponPopup(true)}
                  className="mt-8 lg:mb-0 mb-4 font-poppins font-semibold lg:text-base text-sm text-primary border-b border-primary border-dashed uppercase sm:block hidden"
                >
                  show coupon code
                </button>
              ) : (
                <button className="mt-8 lg:mb-0 mb-4 font-poppins font-semibold lg:text-base text-sm text-primary uppercase border-b border-primary sm:block hidden">
                  show deal
                </button>
              )}
              {showCouponPopup && (
                <CouponPopup
                  storeImage={item.couponImage}
                  storeHeading="Store Name"
                  storeName="Store Name"
                  closePopup={() => setShowCouponPopup(false)}
                />
              )}
            </div>
            <div className="sm:hidden">
              <Icons.rightArrowIconMob />
            </div>
          </div>
        </React.Fragment>
      );
    }
  );
  return (
    <>
      <h1 className="font-montserrat xl:text-4xl sm:text-3xl text-xl font-semibold sm:text-start text-center">
        Music and Musical Instruments Sales & Deals
      </h1>  
      <p className="upppercase font-montserrat text-light-purple font-semibold sm:text-base text-sm sm:text-start text-center mt-3">
        TOP 93 OFFERS AVAILABLE FOR SEPTEMBER 2023
      </p>
      <div className="grid lg:grid-cols-3 sm:grid-cols-2 grid-cols-1 xl:gap-10 sm:gap-5 gap-3 mt-10">
        {renderCategoryDetails}
      </div>
    </>
  );
};

export default CategoriesDetailsCards;

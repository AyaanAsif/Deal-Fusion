import React from "react";
import CategoriesDetailsCards from "./CategoryDetailsCards";
import CategoryDescription from "./CategoryDescription";

const CategoriesDetails: React.FC = () => {
    return (
        <>
        <div className="inner-banner flex justify-center items-center">
        <h1 className="font-montserrat text-3xl font-semibold text-white">
          Categories
        </h1>
      </div>
        <div className="2xl:container mx-auto xl:px-20 lg:px-10 px-5 py-20 flex xl:gap-20 gap-10">
            <div className="xl:w-[25%] w-[30%] sm:block hidden">
                <CategoryDescription/>
            </div>
            <div className="xl:w-[75%] sm:w-[70%] w-full">
                <CategoriesDetailsCards/>
            </div>
        </div>
        </>
    )
}

export default CategoriesDetails;
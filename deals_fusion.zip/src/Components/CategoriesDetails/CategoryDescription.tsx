import React from "react";
import SimilarStores from "../StoreDetails/SimilarStores";

const CategoryDescription: React.FC = () => {
  return (
    <>
      <div className="border border-gray-400 rounded-xl px-4 py-8">
        <p className="text-light-blue font-poppins text-sm">
          Over 50+ offers available, items are moving fast. Act now if you want
          one of your own!
        </p>
        <h1 className="text-xl font-montserrat font-semibold text-header-bg mt-5">
          About Music & Musical Instruments Sales & Deals
        </h1>
        <p className="text-light-blue font-poppins text-sm mt-3">
          Listed above you'll find some of the best Music and Musical
          Instruments coupons, discounts and promotion codes as ranked by the
          users of deals. To use a coupon simply click the coupon code then
          enter the code during the store's checkout process.
        </p>
        <h1 className="text-xl font-montserrat font-semibold text-header-bg mt-5">
          Today's Top Music & Musical Instruments Sales & Deals Offers:
        </h1>
        <p className="text-light-blue font-poppins text-sm mt-3">
          1. Shop The Latest Trends Under $100
        </p>
        <p className="text-light-blue font-poppins text-sm mt-3">
          2. 6% Cash Back For Purchases Sitewide
        </p>
        <div className="flex justify-between items-center mt-6">
          <p className="text-light-blue font-poppins text-sm">Total Offers</p>
          <p className="text-light-blue font-poppins text-sm">50</p>
        </div>
        <div className="flex justify-between items-center mt-3">
          <p className="text-light-blue font-poppins text-sm">Coupon Offers</p>
          <p className="text-light-blue font-poppins text-sm">6</p>
        </div>
        <div className="flex justify-between items-center mt-3">
          <p className="text-light-blue font-poppins text-sm">
            Free Shipping Deals
          </p>
          <p className="text-light-blue font-poppins text-sm">10</p>
        </div>
        <div className="flex justify-between items-center mt-3">
          <p className="text-light-blue font-poppins text-sm">Best Discount</p>
          <p className="text-light-blue font-poppins text-sm">30% Off</p>
        </div>
        <div className="flex justify-between items-center mt-3">
          <p className="text-light-blue font-poppins text-sm">
            Cash Back Offer
          </p>
          <p className="text-light-blue font-poppins text-sm">8%</p>
        </div>
        <SimilarStores/>
      </div>
    </>
  );
};

export default CategoryDescription;

import React, { useEffect } from 'react';
// import Swiper from 'swiper';
// import Swiper from 'swiper/swiper-bundle.min.css'; // Import Swiper CSS
import 'swiper/swiper-bundle.min.css'; // Import Swiper JS

const Slider = () => {
  // useEffect(() => {
  //   const swiper = new Swiper('.swiper', {
  //     effect: 'coverflow',
  //     grabCursor: true,
  //     centeredSlides: true,
  //     coverflowEffect: {
  //       rotate: 0,
  //       stretch: 0,
  //       depth: 100,
  //       modifier: 2.5,
  //     },
  //     keyboard: {
  //       enabled: true,
  //     },
  //     mousewheel: {
  //       thresholdDelta: 70,
  //     },
  //     spaceBetween: 30,
  //     loop: false,
  //     breakpoints: {
  //       640: {
  //         slidesPerView: 2,
  //       },
  //       1024: {
  //         slidesPerView: 3,
  //       },
  //     },
  //   });

  //   swiper.slideTo(1, false, false);
  // }, []);

  return (
    <main>
      <div className="swiper">
        <div className="swiper-wrapper">
          {/* Repeat this slide structure for all your slides */}
          <div className="swiper-slide">
            <div className="swiper-slide-img">
              <img src="https://images.unsplash.com/photo-1543335785-8aadf6d8183c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1932&q=80" alt="" />
              <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
                {/* Add your SVG path here */}
              </svg>
            </div>
            <div className="swiper-slide-content">
              <div>
                <h2>louvre</h2>
                <p>National art museum in Paris, France...</p>
                <a className="show-more" href="https://en.wikipedia.org/wiki/Louvre" target="_blank">
                  <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17.25 8.25L21 12m0 0l-3.75 3.75M21 12H3"></path>
                  </svg>
                </a>
              </div>
            </div>
          </div>
          {/* Repeat for other slides */}
        </div>
      </div>
    </main>
  );
};

export default Slider;

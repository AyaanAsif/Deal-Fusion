import React from "react";

const Error404: React.FC = () => {
  return (
    <div className="2xl:container mx-auto 2xl:px-0 xl:px-20 lg:px-10 px-5 flex flex-col items-center justify-center h-screen">
      <h1 className="sm:text-6xl text-4xl text-primary font-bold font-montserrat">404</h1>
      <h2 className="sm:text-4xl text-2xl font-semibold font-montserrat">Page Not Found</h2>
    </div>
  );
};

export default Error404;

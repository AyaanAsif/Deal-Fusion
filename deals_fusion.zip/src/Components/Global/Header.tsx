import React, { useEffect, useState } from "react";
import * as Icons from "../Global/Icons";
import { Link } from "react-router-dom";

const Header: React.FC = () => {
  const [showSidemenu, setShowSidemenu] = useState<boolean>(false);
  const [showSearch, setShowSearch] = useState<boolean>(false);
  const [showSearchMob, setShowSearchMob] = useState<boolean>(false);

  return (
    <>
      <div className="w-full subscribe-btn sticky top-0 z-50 lg:block hidden border-b border-gray-300">
        <div className="2xl:container mx-auto 2xl:px-36 md:px-10 px-5 flex items-center justify-between py-3">
          <div className="flex items-center xl:gap-28 gap-10">
            <Link to="/" className="cursor-pointer">
              <h2 className="text-2xl font-semibold font-montserrat text-white">LOGO</h2>
            </Link>
            <nav className="flex items-center gap-5">
              <Link to="/all-stores">
                <p className="nav-items">Stores</p>
              </Link>
              <Link to="/coupons">
                <p className="nav-items">Coupons</p>
              </Link>
              <p className="nav-items">Submit Code</p>
              <Link to="/blogs">
                <p className="nav-items">Blogs</p>
              </Link>
            </nav>
          </div>
          <div className="md:flex hidden gap-10">
            <div
              onClick={() => setShowSearch(!showSearch)}
              className="flex border border-white p-1 rounded-md relative"
            >
              <input
                type="text"
                placeholder="Search Here"
                className=" bg-transparent xl:w-56 lg:w-44 px-5 focus:border-0 focus:ring-0 focus:outline-none text-white font-montserrat"
              />
              <div className="p-3 bg-primary text-black fill-current rounded-md">
                <Icons.SearchIcon />
              </div>
              {/* Search Popup */}
              {showSearch && (
                <div className="absolute top-16 right-0 rounded-[12px] bg-white px-5 py-8 w-96">
                  <h4 className="font-montserrat font-semibold text-xl">
                    Stores
                  </h4>
                  <div className="flex items-center gap-5 mt-3">
                    <div className="w-28">
                      <div className="w-20 h-20 bg-[#F2F4FA] rounded-lg flex items-center justify-center">
                        <img
                          src="/images/stores/dell.png"
                          alt=""
                          className="w-12"
                        />
                      </div>
                    </div>
                    <div>
                      <h4 className="font-montserrat text-base font-semibold">
                        Dell
                      </h4>
                      <p className="mt-1 text-light-blue font-poppins font-normal text-sm">
                        Flash Sale Alert! Grab exclusive discounts before
                        they're gone.
                      </p>
                    </div>
                  </div>
                  <div className="my-3 w-full h-[1px] bg-gray-200"></div>
                  <h4 className="font-montserrat font-semibold text-xl">
                    Cashback Offers
                  </h4>
                  <div className="flex items-center gap-5 mt-3">
                    <div className="w-28">
                      <div className="w-20 h-20 bg-[#F2F4FA] rounded-lg flex items-center justify-center">
                        <img
                          src="/images/stores/dell.png"
                          alt=""
                          className="w-12"
                        />
                      </div>
                    </div>
                    <div>
                      <h4 className="font-montserrat text-base font-semibold">
                        Dell
                      </h4>
                      <p className="mt-1 text-light-blue font-poppins font-normal text-sm">
                        Dell Online Cashback 20% Back
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div className="flex items-center gap-5">
              <Link to="/login">
                <button className="font-poppins text-base font-medium text-white">
                  Login
                </button>
              </Link>
              <Link to="/register">
                <button className="font-poppins text-base font-semibold bg-primary hover:bg-header-bg py-3 px-9 rounded-tr-lg rounded-bl-lg hover:text-white hover:border hover:border-white">
                  Sign Up
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Header */}
      <div className="lg:hidden flex justify-between items-center w-full sticky top-0 z-50 p-5 border-b-4 border-header-bg bg-white">
        <div>
          <div
            onClick={() => setShowSidemenu(true)}
            className="fill-current flex overflow-hidden"
          >
            <Icons.HamburgerMenu />
          </div>
          {showSidemenu && (
            <div
              onClick={() => setShowSidemenu(false)}
              className="bg-black/50 w-full h-screen fixed top-0 inset-0 z-[999999]"
            ></div>
          )}
          <div
            className={`bg-white ${
              showSidemenu ? "sm:w-1/2 w-4/5" : "w-0"
            } h-screen fixed top-0 left-0 transition-all ease-in-out duration-300 overflow-hidden z-[999999]`}
          >
            <div className="w-full relative h-full">
              <div
                onClick={() => setShowSidemenu(false)}
                className="absolute top-8 right-5"
              >
                <Icons.CloseIcon />
              </div>
              <nav className="pl-5 pt-20 pb-10">
                <Link to="/all-stores">
                  <p className="nav-items-mob mt-3">Stores</p>
                </Link>
                <Link to="/categories">
                  <p className="nav-items-mob mt-3">Categories</p>
                </Link>
                <Link to="/">
                  <p className="nav-items-mob mt-3">Special Event</p>
                </Link>
              </nav>
              <div className="w-11/12 h-[1px] mx-auto bg-gray-300"></div>
              <div className="pl-5 pt-10 flex gap-5 items-center">
                <Link to="/login">
                  <button className="font-poppins text-base font-normal text-secondary border border-secondary py-3 px-9 rounded-tr-lg rounded-bl-lg">
                    Login
                  </button>
                </Link>
                <Link to="/register">
                  <button className="font-poppins text-base font-normal text-white bg-secondary py-3 px-9 rounded-tr-lg rounded-bl-lg">
                    Sign Up
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
        <Link to="/" className="cursor-pointer">
          <img src="/images/logo.png" alt="" />
        </Link>
        <div onClick={() => setShowSearchMob(true)}>
          <Icons.SearchIcon />
        </div>
        {/* Search Bar */}
        {showSearchMob && (
          <div className="absolute w-full h-full top-4 inset-x-0 px-5">
            <div className="flex items-center gap-3 bg-white rounded-lg px-2">
              <input
                type="text"
                className="w-full h-14 bg-transparent focus:border-0 focus:outline-none focus:ring-0 text-base font-montserrat font-medium"
                placeholder="Search Here..."
              />
              <div onClick={() => setShowSearchMob(false)}>
                <Icons.CloseIcon />
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default Header;

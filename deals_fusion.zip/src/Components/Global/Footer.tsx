import React from "react";
import * as Icons from "../Global/Icons";
import { Link } from "react-router-dom";

const Footer: React.FC = () => {
  return (
    <div className="bg-[#F2F4FA] pt-24">
      <div className="2xl:container mx-auto 2xl:px-10 lg:px-20 md:px-10 px-5">
        <div className="flex flex-col items-center justify-center lg:px-0 sm:px-10 px-5">
          <h1 className="text-[#16213B] font-montserrat md:text-4xl sm:text-3xl text-xl text-center font-semibold">
            Subscribe To Our Newsletter
          </h1>
          <p className="text-light-blue font-poppins text-sm mt-3 text-center">
            Subscribe to our newsletter for exclusive deals, hot offers, and the
            latest coupon updates.
          </p>
          <div className="flex sm:flex-row flex-col justify-between border border-[#DDE1EB] rounded-tr-2xl rounded-bl-2xl mt-10 sm:h-14 h-24 sm:w-[30rem] p-[6px]">
            <input
              type="text"
              placeholder="Enter Email Address"
              className="font-montserrat font-medium text-[#A0A8BE] text-base px-4 sm:pt-0 pt-1 bg-transparent focus:border-0 focus:outline-none focus:ring-0"
            />
            <button className="subscribe-btn px-7 sm:py-0 py-2 text-white font-poppins text-base font-medium">
              Subscribe
            </button>
          </div>
        </div>
        <div className="w-full h-[1px] bg-[#DDE1EB] my-14"></div>
        <div className="grid xl:grid-cols-5 lg:grid-cols-4 md:grid-cols-3 grid-cols-2  lg:gap-20 gap-10 mt-10">
          <div className="sm:col-span-1 col-span-2">
            <img src="/images/footer-logo.png" alt="" />
            <p className="font-poppins text-light-blue font-normal text-sm mt-5 sm:block hidden">
              Discover amazing savings and elevate your shopping experience with
              our trusted online coupon marketplace.
            </p>
            <h2 className="lg:mt-4 mt-8 font-montserrat text-[#16213B] font-semibold lg:text-xl text-base">
              Get Socially Connected
            </h2>
            <div className="lg:mt-6 mt-3 flex items-center sm:flex-nowrap flex-wrap gap-2">
              <div className="w-12 h-12 border border-[#243763] hover:border-secondary text-[#243763] hover:text-white hover:bg-secondary fill-current flex justify-center items-center rounded-[0px_8px] cursor-pointer">
                <Icons.FacebookIcon />
              </div>
              <div className="w-12 h-12 border border-[#243763] hover:border-secondary text-[#243763] hover:text-white hover:bg-secondary fill-current flex justify-center items-center rounded-[0px_8px] cursor-pointer">
                <Icons.TwitterIcon />
              </div>
              <div className="w-12 h-12 border border-[#243763] hover:border-secondary text-[#243763] hover:text-white hover:bg-secondary fill-current flex justify-center items-center rounded-[0px_8px] cursor-pointer">
                <Icons.InstagramIcon />
              </div>
              <div className="w-12 h-12 border border-[#243763] hover:border-secondary text-[#243763] hover:text-white hover:bg-secondary fill-current flex justify-center items-center rounded-[0px_8px] cursor-pointer">
                <Icons.YoutubeIcon />
              </div>
            </div>
          </div>
          <div>
            <h1 className="text-header-bg font-montserrat text-xl font-semibold">
              Quick Links
            </h1>
            <nav className="mt-6 space-y-2">
              <Link to="/about-us">
              <p className="footer-menu">About</p>
              </Link>
              <Link to="/categories">
              <p className="footer-menu mt-2">Top Categories</p>
              </Link>
              <Link to="all-stores">
              <p className="footer-menu mt-2">Top Stores</p>
              </Link>
              <Link to="/blogs">
              <p className="footer-menu mt-2">Blogs</p>
              </Link>
              <p className="footer-menu">Get Chrome Extention</p>
              <p className="footer-menu">Download Our App</p>
            </nav>
          </div>
          <div>
            <h1 className="text-header-bg font-montserrat text-xl font-semibold">
              Get Involved
            </h1>
            <nav className="mt-6 space-y-2">
              <p className="footer-menu">The Real Deals</p>
              <p className="footer-menu">Jobs</p>
              <p className="footer-menu">Press</p>
              <p className="footer-menu">Investor Relations</p>
              <p className="footer-menu">Management Team</p>
              <p className="footer-menu">Community</p>
            </nav>
          </div>
          <div>
            <h1 className="text-header-bg font-montserrat text-xl font-semibold">
              Sell Coupons
            </h1>
            <nav className="mt-6 space-y-2">
              <p className="footer-menu">Join Our Marketplace</p>
              <p className="footer-menu">Run Our Campaign</p>
              <p className="footer-menu">Work For Merchants</p>
              <p className="footer-menu">Sponsorship</p>
              <p className="footer-menu">Affiliate Program</p>
              <p className="footer-menu">Vendor Code</p>
            </nav>
          </div>
          <div>
            <h1 className="text-header-bg font-montserrat text-xl font-semibold">
              Customer Care
            </h1>
            <nav className="mt-6 space-y-2">
              <p className="footer-menu">Contact Us</p>
              <p className="footer-menu">Report Infringement</p>
              <p className="footer-menu">Help Center</p>
              <p className="footer-menu">Refund Policy</p>
              <p className="footer-menu">Privacy Policy</p>
              <p className="footer-menu">Terms and Condition</p>
            </nav>
          </div>
        </div>
        <div className="w-full h-[1px] bg-[#DDE1EB] mt-12"></div>
        <div className="py-5">
          <p className="font-poppins text-xs font-normal text-light-blue sm:text-start text-center">
            © 2023, DealFusion. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Footer;

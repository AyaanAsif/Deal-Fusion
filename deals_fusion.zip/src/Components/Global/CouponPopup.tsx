import React, { useRef, useState } from "react";
import * as Icons from "../Global/Icons";

type Props = {
  closePopup(): void | any;
  storeImage?: string;
  storeHeading?: string;
  storeName?: string;
};

const CouponPopup: React.FC<Props> = ({
  closePopup,
  storeImage,
  storeHeading,
  storeName,
}) => {
  const [buttonText, setButtonText] = useState("Copy");
  const textToCopyRef = useRef<HTMLInputElement | null>(null);

  const handleCopyClick = () => {
    if (textToCopyRef.current) {
      textToCopyRef.current.select();
      textToCopyRef.current.setSelectionRange(0, 99999);

      document.execCommand("copy");
      setButtonText("Copied!");

      setTimeout(() => {
        setButtonText("Copy");
      }, 1000);
    }
  };
  return (
    <>
      <div
        onClick={closePopup}
        className="fixed top-0 inset-0 bg-black/10 backdrop-blur-sm z-[999999] w-full h-screen"
      ></div>
      <div className="fixed top-0 inset-0 z-[9999999] w-full h-full flex justify-center items-center">
        <div className="bg-white sm:w-[40rem] w-full sm:h-[90%] h-screen relative sm:rounded-3xl overflow-y-auto">
          <div className="p-5">
            <div
              onClick={closePopup}
              className="absolute top-6 right-6 cursor-pointer border border-gray-500 rounded-full p-1 hover:text-secondary hover:border-secondary"
            >
              <Icons.CloseIconSm />
            </div>
            <div className="flex flex-col justify-center items-center mt-6">
              <div className="rounded-2xl bg-gray-100 w-28 h-28 flex justify-center items-center p-4">
                <img src={storeImage} alt="" className="w-full h-full" />
              </div>
              <h2 className="font-montserrat sm:text-2xl text-lg font-semibold mt-8 sm:text-start text-center">
                {storeHeading}
              </h2>
              <p className="mt-10 font-montserrat text-sm font-normal">
                Copy and paste this code at {storeName}
              </p>
              <div className="flex sm:flex-row flex-col items-center mt-4 rounded-lg border border-dashed border-primary bg-[#F2F4FA] p-2 sm:w-[22rem] sm:h-16">
                <input
                  type="text"
                  value="COUPON746"
                  id="copyText"
                  readOnly={true}
                  className="w-full font-montserrit focus:border focus:border-r-0 focus:outline-none bg-transparent uppercase font-semibold text-2xl sm:text-start text-center"
                  ref={textToCopyRef}
                />
                <button
                  className="flex items-center justify-center btn-bg text-white text-base font-poppins font-medium rounded-lg uppercase h-full sm:px-5 px-10 sm:py-0 py-4 sm:mt-0 mt-5"
                  id="copyButton"
                  onClick={handleCopyClick}
                >
                  {buttonText}
                </button>
              </div>
              <button className="flex items-center justify-center rounded-[2px_8px] btn-bg text-white text-base font-poppins px-5 py-3 mt-5">
                Continue To {storeName}
              </button>
              <div className="mt-14 flex items-center gap-10">
                <p className="font-poppins text-sm text-light-blue">
                  Did The Code Work?
                </p>
                <div className="flex gap-2">
                  <div className="p-2 border border-gray-300 hover:border-secondary rounded-full text-secondary hover:text-white fill-current hover:bg-secondary cursor-pointer">
                    <Icons.thumbIcon />
                  </div>
                  <div className="p-2 border border-gray-300 hover:border-secondary rounded-full text-secondary hover:text-white fill-current hover:bg-secondary cursor-pointer rotate-180">
                    <Icons.thumbIcon />
                  </div>
                </div>
              </div>
              <div className="px-5 sm:block hidden"> 
                <div className="w-full h-[1px] my-5 bg-gray-200"></div>
                <div className="w-full">
                  <h1 className="font-montserrat text-2xl font-semibold text-start">
                    Offer Details
                  </h1>
                  <div className="flex gap-2 items-center mt-3">
                    <img src="/svgs/eye-icon.svg" alt="" />
                    <p className="text-light-blue font-poppins text-sm">
                      Over 350 sold today, this item is moving fast. Act now if
                      you want one of your own!
                    </p>
                  </div>
                  <div className="flex gap-2 items-center mt-3">
                    <img src="/svgs/clock-icon.svg" alt="" />
                    <p className="text-light-blue font-poppins text-sm">
                      Hurry up, Offer expire in 12 days
                    </p>
                  </div>
                </div>
                <div className="w-full my-5">
                  <h1 className="font-montserrat text-2xl font-semibold text-start">
                    Share This Coupon
                  </h1>
                  <div className="flex items-center gap-3 mt-3">
                    <div className="w-10 h-10 p-2 flex justify-center items-center border border-gray-300 text-secondary fill-current hover:text-primary rounded-full cursor-pointer">
                      <Icons.FacebookIcon />
                    </div>
                    <div className="w-10 h-10 p-2 flex justify-center items-center border border-gray-300 text-secondary fill-current hover:text-primary rounded-full cursor-pointer">
                      <Icons.TwitterIcon />
                    </div>
                    <div className="w-10 h-10 p-2 flex justify-center items-center border border-gray-300 text-secondary fill-current hover:text-primary rounded-full cursor-pointer">
                      <Icons.InstagramIcon />
                    </div>
                    <div className="w-10 h-10 p-2 flex justify-center items-center border border-gray-300 text-secondary fill-current hover:text-primary rounded-full cursor-pointer">
                      <Icons.YoutubeIcon />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CouponPopup;

import React from "react";

const ChromeExtention: React.FC = () => {
  return (
    <>
      <div className="bg-primary rounded-lg w-full mt-14 h-[32rem] relative lg:flex hidden flex-col items-center">
        <div className="px-4 py-5 flex flex-col items-start">
          <h2 className="font-montserrat text-2xl text-white font-semibold">
            Get Our Chrome Extention
          </h2>
          <p className="mt-3 font-poppins text-sm font-normal text-white">
            Get Our Chrome Extention for Real-Time Coupon Updates and Easy Buy
            and Sell Options.
          </p>
          <button className="px-8 py-3 rounded-[2px_8px] bg-secondary text-white font-poppins text-base font-medium mt-8">Add Extention</button>
        </div>
        <div className="absolute bottom-0 right-0 bg-secondary w-[90%] h-36 rounded-br-lg rounded-tl-[200px]"></div> 
        <img src="images/store-details/img-1.png" alt="" className="absolute bottom-10" />
      </div>
    </>
  );
};

export default ChromeExtention;

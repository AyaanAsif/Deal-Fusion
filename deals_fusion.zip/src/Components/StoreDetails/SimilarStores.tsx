import React from "react";

const SimilarStores: React.FC = () => {
  return (
    <>
      <h3 className="font-montserrat text-xl font-semibold text-[#16213B] mt-5">
        Similar Stores
      </h3>
      <div className="mt-6 grid grid-cols-2 gap-5">
        <div className="border border-[#DDE1EB] h-20 rounded-tl-2xl rounded-br-2xl flex justify-center items-center">
          <img src="/svgs/subway.svg" alt="" className="w-20" />
        </div>
        <div className="border border-[#DDE1EB] h-20 rounded-tl-2xl rounded-br-2xl flex justify-center items-center">
          <img src="/svgs/samsung.svg" alt="" className="w-20" />
        </div>
        <div className="border border-[#DDE1EB] h-20 rounded-tl-2xl rounded-br-2xl flex justify-center items-center">
          <img src="/svgs/adidas.svg" alt="" className="w-20" />
        </div>
        <div className="border border-[#DDE1EB] h-20 rounded-tl-2xl rounded-br-2xl flex justify-center items-center">
          <img src="/svgs/zara.svg" alt="" className="w-20" />
        </div>
        <div className="border border-[#DDE1EB] h-20 rounded-tl-2xl rounded-br-2xl flex justify-center items-center">
          <img src="/svgs/dell.svg" alt="" className="w-20" />
        </div>
        <div className="border border-[#DDE1EB] h-20 rounded-tl-2xl rounded-br-2xl flex justify-center items-center">
          <img src="/svgs/subway.svg" alt="" className="w-20" />
        </div>
      </div>
    </>
  );
};

export default SimilarStores;

import React from "react";

const RightSideDescription: React.FC = () => {
  return (
    <>
      <div className="border border-[#DDE1EB] rounded-2xl sm:py-8 py-5 sm:px-6 px-3 mt-20">
        <h1 className="font-montserrat sm:text-3xl text-xl sm:font-semibold font-bold text-black">
          More information about adidas
        </h1>
        <h2 className="font-montserrat sm:text-xl text-lg font-medium text-black mt-4">
          How to Redeem an adidas Discount Code
        </h2>
        <p className="text-light-blue font-poppins text-sm font-normal mt-5">
          1. Browse adidas.com for shoes, appreal, accessories, and more. When
          you find an item you like, choose your size and click "Addd tp Bag" on
          its product page.
        </p>
        <p className="text-light-blue font-poppins text-sm font-normal mt-2">
          2. A shopping bag will pop up. Click "View Bag" opn the pop up.
        </p>
        <p className="text-light-blue font-poppins text-sm font-normal mt-2">
          3. You'll be redirected to a shopping summary page. Click the "USA A
          Promo Code" link on the bottom right.
        </p>
        <p className="text-light-blue font-poppins text-sm font-normal mt-2">
          4. Enter your discount code in the input box that appears that says
          "Enter your promo code."
        </p>
        <p className="text-light-blue font-poppins text-sm font-normal mt-2">
          5. Click "Apply" to enjoy your adidas discount.
        </p>
        <h2 className="font-montserrat sm:text-xl text-lg font-medium text-black mt-8">
          What to Do if Your adidas Coupon Code Isn't Working
        </h2>
        <div className="flex items-center gap-3 mt-5">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins text-sm font-normal">
            Verify that you have correctly input your adidas promo code.
          </p>
        </div>
        <div className="flex items-center gap-3 mt-5">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins text-sm font-normal">
            Ensure your cart meets the minimum purchase amount or any additional
            requirements.
          </p>
        </div>
        <div className="flex items-center gap-3 mt-5">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins text-sm font-normal">
            Make sure the promo code which you selected it still valid and has
            not yet expired.
          </p>
        </div>
        <div className="flex items-center gap-3 mt-5">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins text-sm font-normal">
            If you are still having any trouble, try a different adidas discount
            code from CouponFollow instead.
          </p>
        </div>
        <h2 className="font-montserrat sm:text-xl text-lg font-medium text-black mt-8">
          Stacking and Combinging adidas Coupons
        </h2>
        <p className="text-light-blue font-poppins text-sm font-normal mt-2">
          From our research, we’ve found that you cannot combine or stack adidas
          coupons. When you apply your first coupon to the coupon input box,
          that box disappears and is replaced with a box that says “Promo Code
          Applied.” If you want to apply another coupon or discount, you need to
          remove the original discount code first. So, make sure you use the
          best coupon code for your purchase, and sign up to be an adiClub
          member for even more discounts, sales, and savings.
        </p>

        <h2 className="font-montserrat sm:text-xl text-lg font-medium text-black mt-8">
          More Information for adidas Shoppers
        </h2>
        <div className="flex items-center gap-3 mt-5">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins text-sm font-normal">
            Shop in the adidas online sale section to score adidas brand items
            up to 40% off or more.
          </p>
        </div>
        <div className="flex items-center gap-3 mt-5">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins text-sm font-normal">
            Visit the adidas Promotions page for the current promotions,
            discounts, and sales.
          </p>
        </div>
        <div className="flex items-center gap-3 mt-5">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins text-sm font-normal">
            Browse the adidas homepage and open the adidas app to see if adidas
            is offering seasonal sales. These exclusive deals and sales are
            featured clearly on the adidas homepage and on the adidas app.
          </p>
        </div>
        <div className="flex items-center gap-3 mt-5">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins text-sm font-normal">
            Sign up for the adidas email newsletter, and you'll receive an
            introductory offer of 15% off. Newsletter subscribers regularly
            receive coupons and other promotions in their inbox.
          </p>
        </div>
        <div className="flex items-center gap-3 mt-5">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins text-sm font-normal">
            Students receive 15% off and free shipping when they verify their
            student ID through UNiDAYS.
          </p>
        </div>
        <div className="flex items-center gap-3 mt-5">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins text-sm font-normal">
            Medical professionals, first responders, nurses, military members,
            and teachers get a 30% discount online and in-store and 20% off when
            they shop adidas factory outlets.
          </p>
        </div>
        <div className="flex items-center gap-3 mt-5">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins text-sm font-normal">
            Create an adiClub membership and get 15% off your next purchase.
            Members get member-only access to products and sales, access to the
            adidas Running and Training apps, free shipping, and more.
          </p>
        </div>
        <div className="flex items-center gap-3 mt-5">
          <img src="/svgs/bullet.svg" alt="" />
          <p className="text-light-blue font-poppins text-sm font-normal">
            Follow adidas on Facebook, Instagram, and Tiktok for more adidas
            news, social giveaways, social discounts, and more.
          </p>
        </div>
        <h2 className="font-montserrat sm:text-xl text-lg font-medium text-black mt-8">
          Save During the Holidays With adidas
        </h2>
        <p className="text-light-blue font-poppins text-sm font-normal mt-2">
          We’ve seen adidas offer even bigger discounts of up to 60% off
          apparel, shoes, accessories, and more during the holidays, like
          Christmas, or during commercial holidays like Black Friday and Cyber
          Monday. You can also stock up on essentials and basics for next year
          when you shop the end-of-season sales, where they tend to offer big
          discounts of up to 40-60% off.
        </p>
        <p className="text-light-blue font-poppins text-sm font-normal mt-4">
          Probably the best deal we’ve seen to date, however, is the sale on
          adidas gift cards. A couple times a year (especially during the
          adiClub member sale and during the Christmas holiday season), adidas
          will offer savings on gift cards, such as a $100 gift card for only
          $75. Make sure you sign up for the adidas email newsletter to make
          sure you don’t miss these deals and more.
        </p>
        <h2 className="font-montserrat text-xl font-semibold text-black mt-8">
          More About adidas
        </h2>
        <h2 className="font-montserrat sm:text-xl text-lg font-medium text-black mt-8">
          adidas Shipping Policy
        </h2>
        <p className="text-light-blue font-poppins text-sm font-normal mt-2">
          adidas offers free standard shipping when you create an adiClub
          account. You can expect your adidas order to be delivered within 3-5
          business days. If you personalized or customized any items, your items
          will take an additional five days for processing. View the entire
          adidas shipping policy for online orders.
        </p>
        <h2 className="font-montserrat sm:text-xl text-lg font-medium text-black mt-8">
          adidas Return Policy & Refunds
        </h2>
        <p className="text-light-blue font-poppins text-sm font-normal mt-2">
          adidas offers refunds on most items within 30 days of purchase, as
          long as the product is new, unused, and has its original tags or
          packaging. Any final sale and custom-made adidas shoes and apparel
          won't be eligible for a return. You can return items by mail or at any
          retail location. Visit the company's website to view the adidas return
          and refund policy.
        </p>
        <h2 className="font-montserrat sm:text-xl text-lg font-medium text-black mt-8">
          Contact adidas Customer Service
        </h2>
        <p className="text-light-blue font-poppins text-sm font-normal mt-2">
          The adidas customer service team can be reached at 1-800-982-9337 and
          is available from 5 a.m. to 8 p.m. PST from Monday through Saturday.
          You can also email the company at contactus@adidas.com or use the
          chatbot customer support on the bottom right of the website at any
          time.
        </p>
        <h2 className="font-montserrat sm:text-xl text-lg font-medium text-black mt-8">
          About adidas
        </h2>
        <p className="text-light-blue font-poppins text-sm font-normal mt-2">
          adidas is a top manufacturer of shoes and apparel for sports as well
          as casual, everyday wear. The company designs and produces equipment
          for basketball, soccer, football, golf, running, swimming, and more.
        </p>
        <p className="text-light-blue font-poppins text-sm font-normal mt-4">
          adidas carries infant and children's sizes 0-14, men's sizes XS-3XL,
          and women's sizes XXS-2XL. Their shoe sizes span a wider range than
          most apparel brands. If you have an uncommon shoe size, you'll
          probably find what you need at adidas.
        </p>
        <p className="text-light-blue font-poppins text-sm font-normal mt-4">
          Loved by athletes everywhere and adored by fashion and lifestyle
          bloggers, adidas is a household name that's worn by consumers around
          the world. adidas creates classic and modern sportswear and wardrobe
          pieces that resonate with a global audience
        </p>
      </div>
    </>
  );
};

export default RightSideDescription;

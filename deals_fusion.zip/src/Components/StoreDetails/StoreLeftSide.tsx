import React from "react";
import { storeDescription } from "../../Mock/StoreDetailsMock";
import * as Icons from "../Global/Icons";
import SimilarStores from "./SimilarStores";
import ChromeExtention from "../StoreDetails/ChromExtention";

const StoreLeftSide: React.FC = () => {
  const storeDescriptionData: any = storeDescription;

  return (
    <>
      <div className="lg:w-full flex lg:flex-col sm:flex-row flex-col lg:items-start items-center sm:gap-10 gap-5">
        <div className="bg-[#F2F4FA] flex justify-center items-center lg:py-16 lg:w-full sm:w-44 w-28 lg:h-auto sm:h-44 h-28 lg:rounded-lg rounded-full">
          <img
            src={storeDescriptionData.storeImage}
            alt=""
            className="lg:w-auto sm:w-24 w-16"
          />
        </div>
        <div className="lg:hidden">
          <h1 className="font-montserrat font-bold md:text-3xl sm:text-2xl text-lg text-header-bg sm:text-start text-center">
            Adidas Coupon & Promo Codes
          </h1>
          <p className="font-montserrat sm:font-semibold font-medium sm:text-base text-sm text-header-bg mt-5 uppercase sm:text-start text-center">
            Top 47 offers available for Jult 2023
          </p>
        </div>
      </div>
      <div className="lg:block hidden">
        <div className="flex items-center justify-between mt-4">
          <h2 className="font-montserrat text-3xl font-semibold text-[#16213B] lowercase">
            {storeDescriptionData.storeName}
          </h2>
          <button className="uppercase bg-[#3F9B37] px-3 py-2 text-white font-poppins text-xs rounded-md">
            Follow
          </button>
        </div>
        <p className="mt-4 font-poppins text-light-blue text-sm">
          {storeDescriptionData.description}
        </p>
        <h2 className="font-montserrat text-[#16213B] font-semibold text-xl mt-7">
          {storeDescriptionData.todayOffer}
        </h2>
        <p className="mt-4 font-poppins text-light-blue text-sm">
          1. {storeDescriptionData.firstOffer}
        </p>
        <p className="mt-2 font-poppins text-light-blue text-sm">
          2. {storeDescriptionData.secondOffer}
        </p>
        <div className="flex justify-between mt-5">
          <p className="font-poppins text-sm text-light-blue">Total Offers</p>
          <p className="font-poppins text-sm text-light-blue">
            {storeDescriptionData.totalOffer}
          </p>
        </div>
        <div className="flex justify-between mt-5">
          <p className="font-poppins text-sm text-light-blue">Coupon Codes</p>
          <p className="font-poppins text-sm text-light-blue">
            {storeDescriptionData.couponCode}
          </p>
        </div>
        <div className="flex justify-between mt-5">
          <p className="font-poppins text-sm text-light-blue">
            Free Shipping Deals
          </p>
          <p className="font-poppins text-sm text-light-blue">
            {storeDescriptionData.deals}
          </p>
        </div>
        <div className="flex justify-between mt-5">
          <p className="font-poppins text-sm text-light-blue">Best Discount</p>
          <p className="font-poppins text-sm text-light-blue">
            {storeDescriptionData.bestDiscount}
          </p>
        </div>
        <div className="flex justify-between mt-5">
          <p className="font-poppins text-sm text-light-blue">
            Cash Back Offer
          </p>
          <p className="font-poppins text-sm text-light-blue">
            {storeDescriptionData.cashBackOffer}
          </p>
        </div>
        <h2 className="font-montserrat text-[#16213B] font-semibold text-xl mt-7">
          About{" "}
          <span className="lowercase">{storeDescriptionData.storeName}</span>
        </h2>
        <p className="mt-2 font-poppins text-light-blue text-sm">
          {storeDescriptionData.aboutDescription}
        </p>
        <h3 className="font-montserrat text-[#16213B] font-normal text-xl mt-7">
          More About{" "}
          <span className="lowercase">{storeDescriptionData.storeName}</span>
        </h3>
        <p className="mt-2 font-poppins text-light-blue text-sm">
          {storeDescriptionData.moreDescription}
        </p>
        <button className="flex items-center gap-3 font-poppins font-semibold text-sm text-[#243763] mt-5">
          Read More
          <Icons.rightArrowIcon />
        </button>
        <h3 className="font-montserrat text-[#16213B] font-semibold text-xl mt-7">
          <span className="lowercase">{storeDescriptionData.storeName}</span>{" "}
          Saving Hacks
        </h3>
        <h3 className="font-montserrat text-base font-medium text-[#16213B] mt-3">
          {storeDescriptionData.storeSavingHacks}
        </h3>
        <p className="font-poppins text-sm text-light-blue font-normal mt-3">
          {storeDescriptionData.storeHacksDescription}
        </p>
        <h3 className="font-montserrat text-base font-medium text-[#16213B] mt-6">
          Does Adidas offer free shipping?
        </h3>
        <button className="flex items-center gap-3 font-poppins font-semibold text-sm text-[#243763] mt-5">
          See Details
          <Icons.rightArrowIcon />
        </button>
        <h3 className="font-montserrat text-base font-medium text-[#16213B] mt-6">
          Is ther an adidas student discount?
        </h3>
        <button className="flex items-center gap-3 font-poppins font-semibold text-sm text-[#243763] mt-5">
          See Details
          <Icons.rightArrowIcon />
        </button>
        <h3 className="font-montserrat text-base font-medium text-[#16213B] mt-6">
          Can I get a discount on my adidas order if I'm a member of the
          military?
        </h3>
        <button className="flex items-center gap-3 font-poppins font-semibold text-sm text-[#243763] mt-5">
          See Details
          <Icons.rightArrowIcon />
        </button>
        <h3 className="font-montserrat text-base font-medium text-[#16213B] mt-6">
          Does adidas offer discounts for teachers?
        </h3>
        <button className="flex items-center gap-3 font-poppins font-semibold text-sm text-[#243763] mt-5">
          See Details
          <Icons.rightArrowIcon />
        </button>
        <h3 className="font-montserrat text-base font-medium text-[#16213B] mt-6">
          Can I get a discount on my order if I'm a first responder or medical
          professional?
        </h3>
        <button className="flex items-center gap-3 font-poppins font-semibold text-sm text-[#243763] mt-5">
          See Details
          <Icons.rightArrowIcon />
        </button>
        <h3 className="font-montserrat text-xl font-semibold text-[#16213B] mt-6">
          Rate adidas
        </h3>
        <div className="flex items-center justify-between mt-4">
          <div className="flex gap-2">
            <p className="font-poppins text-[#FFC947] text-base font-medium">
              4.8
            </p>
            <div className="flex items-center gap-1">
              <img src="/svgs/filled-star.svg" alt="" />
              <img src="/svgs/filled-star.svg" alt="" />
              <img src="/svgs/filled-star.svg" alt="" />
              <img src="/svgs/filled-star.svg" alt="" />
              <img src="/svgs/unfilled-star.svg" alt="" />
            </div>
          </div>
          <p className="text-light-blue font-poppins text-sm font-medium">
            2,102 Ratings
          </p>
        </div>
        <h3 className="font-montserrat text-base font-medium text-[#16213B] mt-2">
          Add Your Rating
        </h3>
        <div className="flex gap-1">
          <img src="/svgs/unfilled-star.svg" alt="" />
          <img src="/svgs/unfilled-star.svg" alt="" />
          <img src="/svgs/unfilled-star.svg" alt="" />
          <img src="/svgs/unfilled-star.svg" alt="" />
          <img src="/svgs/unfilled-star.svg" alt="" />
        </div>
        <SimilarStores />
      </div>
      
    </>
  );
};

export default StoreLeftSide;

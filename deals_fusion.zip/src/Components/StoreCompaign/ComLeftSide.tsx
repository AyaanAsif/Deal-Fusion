import React from "react";
import { storeDescription } from "../../Mock/StoreDetailsMock";

const ComLeftSide: React.FC = () => {
  const storeDescriptionData: any = storeDescription;

  return (
    <>
      <div className="lg:border border-[#DDE1EB] rounded-2xl lg:p-6 lg:w-full flex lg:flex-col sm:flex-row flex-col lg:items-start items-center sm:gap-10 gap-5">
        <div className="bg-[#F2F4FA] flex justify-center items-center lg:py-16 lg:w-full sm:w-44 w-28 lg:h-auto sm:h-44 h-28 lg:rounded-lg rounded-full">
          <img
            src={storeDescriptionData.storeImage}
            alt=""
            className="lg:w-auto sm:w-24 w-16"
          />
        </div>
        <div className="lg:hidden">
          <h1 className="font-montserrat font-bold md:text-3xl sm:text-2xl text-lg text-header-bg sm:text-start text-center">
            Adidas Coupon & Promo Codes
          </h1>
          <p className="font-montserrat sm:font-semibold font-medium sm:text-base text-sm text-header-bg mt-5 uppercase sm:text-start text-center">
            Top 47 offers available for Jult 2023
          </p>
        </div>
      </div>
      <div className="lg:block hidden w-full mt-10">
        <div className="border border-[#DDE1EB] rounded-2xl p-6 w-full">
          <h1 className="font-montserrat text-2xl font-semibold gradient-text">
            Discount Type
          </h1>
          <div className="flex justify-between items-center mt-6">
            <div className="flex gap-3 items-center">
              <input type="checkbox" />
              <p className="text-light-blue text-base font-normal font-poppins">
                Buy One Get One
              </p>
            </div>
            <p className="text-light-blue text-base font-normal font-poppins">
              (20)
            </p>
          </div>
          <div className="flex justify-between items-center mt-3">
            <div className="flex gap-3 items-center">
              <input type="checkbox" />
              <p className="text-light-blue text-base font-normal font-poppins">
                Free Shipping
              </p>
            </div>
            <p className="text-light-blue text-base font-normal font-poppins">
              (16)
            </p>
          </div>
          <div className="flex justify-between items-center mt-3">
            <div className="flex gap-3 items-center">
              <input type="checkbox" />
              <p className="text-light-blue text-base font-normal font-poppins">
                Free Gift
              </p>
            </div>
            <p className="text-light-blue text-base font-normal font-poppins">
              (45)
            </p>
          </div>
          <div className="flex justify-between items-center mt-3">
            <div className="flex gap-3 items-center">
              <input type="checkbox" />
              <p className="text-light-blue text-base font-normal font-poppins">
                50% off
              </p>
            </div>
            <p className="text-light-blue text-base font-normal font-poppins">
              (04)
            </p>
          </div>
          <div className="flex justify-between items-center mt-3">
            <div className="flex gap-3 items-center">
              <input type="checkbox" />
              <p className="text-light-blue text-base font-normal font-poppins">
                Other
              </p>
            </div>
            <p className="text-light-blue text-base font-normal font-poppins">
              (04)
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default ComLeftSide;

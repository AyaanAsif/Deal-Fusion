import React, { useState } from "react";
import * as Icons from "../Global/Icons";
import {
  storeDescription,
  storeDetailsData,
} from "../../Mock/StoreDetailsMock";
import ComLeftSide from "./ComLeftSide";

const StoreCompaign: React.FC = () => {
  const [showHover, setShowHover] = useState<boolean>(false);
  const [showDetails, setShowDetails] = useState<boolean>(false);

  const storeDetailsMockData: any = storeDetailsData;
  const storeDescriptionData: any = storeDescription;

  const renderStoreDetialsData = storeDetailsMockData.map(
    (item: any, index: number) => {
      return (
        <React.Fragment key={`${item.id}${index}`}>
          <div className="w-full rounded-tr-2xl">
            <div className="w-full border border-[#DDE1EB] rounded-[2px_16px] flex sm:flex-row flex-col items-center justify-between gap-3 h-full overflow-hidden bg-white ">
              <div className="flex gap-3 items-center sm:px-4 px-2 sm:py-5 py-3">
                <div className="sm:py-5 py-3 sm:px-5 px-3 bg-[#F6F7FB] rounded-md">
                  <p className="text-center font-montserrat sm:text-2xl text-lg font-bold text-[#243763] uppercase">
                    {item.discount[0]}
                  </p>
                  <p className="text-center font-montserrat text-xs font-semibold text-[#243763] uppercase">
                    {item.discount[1]}
                  </p>
                </div>
                <div>
                  <p className="sm:text-sm text-xs  gradient-text font-poppins font-semibold uppercase">
                    {item.couponType === "Show Code" ? "Code" : "Sale"}
                  </p>
                  <h1 className="font-montserrat xl:text-xl sm:text-lg text-sm font-semibold text-[#16213B]">
                    {item.couponHeading}
                  </h1>
                  <p className="sm:text-sm text-xs  text-[#A0A8BE] font-poppins font-medium mt-2">
                    {item.couponDates}
                  </p>
                </div>
              </div>
              <div className="w-20 h-[9.2rem] sm:flex hidden flex-col items-center gap-3">
                <div className="h-1/4 w-full bg-[#F6F7FB] card-top"></div>
                <div className="h-3/5 w-1 border-l-2 border-dashed border-[#DDE1EB]"></div>
                <div className="h-1/4 w-full bg-[#F6F7FB] card-bottom"></div>
              </div>
              <div className="w-56 px-4 py-5 sm:block hidden">
                {item.couponType === "Show Code" ? (
                  <button
                    onMouseEnter={() => setShowHover(true)}
                    onMouseLeave={() => setShowHover(false)}
                    className="code-main"
                  >
                    <div className="inner-btn">{item.couponCode}</div>
                    <div
                      className={`outer-btn ${
                        showHover ? "w-[154px]" : "w-[164px]"
                      }`}
                    >
                      {item.couponType}
                    </div>
                    <div
                      className={`absolute top-0 transition-all ease-in-out duration-500 ${
                        showHover ? "right-2" : "right-0"
                      }`}
                    >
                      <Icons.CouponUpperElement />
                    </div>
                  </button>
                ) : (
                  <button className="button">{item.couponType}</button>
                )}
              </div>
              <div className="w-full bg-light-blue flex justify-center sm:hidden text-white font-montserrat font-semibold py-1">
                {item.couponType}
              </div>
            </div>
            {/* <div onClick={() => setShowDetails(!showDetails)} className="bg-[#F6F7FB] w-full py-3 px-5 sm:flex hidden items-center gap-2 cursor-pointer">
              <p className="see-details">See Details</p>
              <Icons.rightArrowIcon />
            </div> */}
            {/* <div className={`overflow-hidden ${showDetails ? "h-full p-5" : "h-0"}`}>
              <p className="text-light-blue font-poppins text-sm font-normal">
                {item.couponDetails.description}
              </p>
              <div className="mt-8 flex items-center gap-3">
                <img src="/svgs/eye-icon.svg" alt="" />
                <p className="text-light-blue font-poppins text-sm font-normal">
                  {item.couponDetails.sellingDetails}
                </p>
              </div>
              <div className="mt-3 flex items-center gap-3">
                <img src="/svgs/clock-icon.svg" alt="" />
                <p className="text-light-blue font-poppins text-sm font-normal">
                  {item.couponDetails.expiryDetails}
                </p>
              </div>
              <div className="mt-3 flex items-center gap-3">
                <img src="/svgs/verified-icon.svg" alt="" />
                <p className="text-light-blue font-poppins text-sm font-normal">
                  {item.couponDetails.couponVerfication}
                </p>
              </div>
            </div> */}
          </div>
        </React.Fragment>
      );
    }
  );

  return (
    <div className="2xl:container mx-auto 2xl:px-0 xl:px-20 lg:px-10 px-5">
      <div className="flex py-14 gap-4">
        <span className="flex items-center gap-2">
          <p className="font-poppins text-sm font-medium text-primary uppercase">
            Home
          </p>
          <Icons.rightArrowIcon />
        </span>
        <span className="flex items-center gap-2">
          <p className="font-poppins text-sm font-medium text-primary uppercase">
            Stores
          </p>
          <Icons.rightArrowIcon />
        </span>
        <p className="font-poppins text-sm font-medium text-primary uppercase">
          {storeDescriptionData.storeName}
        </p>
      </div>
      <div className="flex lg:flex-row flex-col gap-10 mb-20">
        <div className="xl:w-1/5 lg:w-[30%] flex lg:flex-col flex-row lg:justify-start justify-center items-center h-full">
          <ComLeftSide />
        </div>
        <div className="xl:w-4/5 lg:w-[70%] w-full">
          <div className="lg:block hidden">
            <h1 className="font-montserrat font-bold xl:text-4xl text-3xl text-header-bg">
              Adidas Coupon & Promo Codes
            </h1>
            <p className="font-montserrat font-semibold text-base text-header-bg mt-5 uppercase">
              Top 47 offers available for Jult 2023
            </p>
          </div>
          <div className="mt-8 space-y-4">{renderStoreDetialsData}</div>
        </div>
      </div>
    </div>
  );
};

export default StoreCompaign;

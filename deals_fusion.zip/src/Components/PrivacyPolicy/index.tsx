import React from "react";

const PrivacyPolicy: React.FC = () => {
  return (
    <>
      <div className="inner-banner flex justify-center items-center">
        <h1 className="font-montserrat sm:text-3xl text-xl font-semibold text-white">
          Privacy Policy
        </h1>
      </div>
      <div className="2xl:container mx-auto 2xl:px-0 xl:px-20 lg:px-10 px-5 py-20">
        <h2 className="text-header-bg font-montserrat sm:text-4xl text-2xl font-semibold">
          Privacy Policy For Deals
        </h2>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          At deals.com we take your privacy seriously. This Privacy Policy
          outlines how we collect, use, disclose, and safeguard your personal
          information when you access and use our coupon buy and sell website.
          By using our website, you consent to the practices described in this
          policy.
        </p>
        <h4 className="mt-8 font-montserrat text-2xl font-semibold text-header-bg">
          Information We Collect
        </h4>
        <h4 className="mt-4 font-montserrat text-xl font-semibold text-header-bg">
          1. Personal Information:
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          We may collect personal information that you provide directly to us
          when registering an account, completing transactions, or contacting
          our customer support. This may include your name, email address,
          postal address, phone number, and other identifying information.
        </p>
        <h4 className="mt-4 font-montserrat text-xl font-semibold text-header-bg">
          2. Transaction Information:
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          We collect information related to your coupon buying and selling
          activities on our website, including coupon listings, purchases,
          sales, and payment details.
        </p>
        <h4 className="mt-4 font-montserrat text-xl font-semibold text-header-bg">
          3. Device and Log Information:
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          We automatically collect certain information about your device and
          usage of our website. This includes IP address, browser type,
          operating system, referring URLs, pages visited, and dates/times of
          access.
        </p>
        <h4 className="mt-4 font-montserrat text-xl font-semibold text-header-bg">
          4. Cookies and Similar Technologies:
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          We may use cookies and similar technologies to enhance your user
          experience, personalize content, and track usage data. You can manage
          your cookie preferences through your browser settings.
        </p>
        <h2 className="mt-8 font-montserrat text-2xl font-semibold text-header-bg">
          How We Use Your Information
        </h2>
        <h4 className="mt-4 font-montserrat text-xl font-semibold text-header-bg">
          1. Provide Services:
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          We use your personal information to facilitate coupon buying and
          selling transactions, process payments, and provide customer support.
        </p>
        <h4 className="mt-4 font-montserrat text-xl font-semibold text-header-bg">
          2. Communication:
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          We may use your email address to send you important updates,
          promotional offers, and newsletters. You can opt-out of marketing
          communications at any time.
        </p>
        <h4 className="mt-4 font-montserrat text-xl font-semibold text-header-bg">
          3. Analytics:
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          We use data analytics to understand user behavior and improve the
          functionality and performance of our website.
        </p>
        <h4 className="mt-4 font-montserrat text-xl font-semibold text-header-bg">
          4. Legal Compliance:
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          We may use your information to comply with applicable laws,
          regulations, and legal processes.
        </p>
        <h4 className="mt-8 font-montserrat text-2xl font-semibold text-header-bg">
          Disclosure of Your Information
        </h4>
        <h4 className="mt-4 font-montserrat text-xl font-semibold text-header-bg">
          1. Third-Party Service Providers:
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          We may share your personal information with third-party service
          providers to perform various functions on our behalf, such as payment
          processing and analytics.
        </p>
        <h4 className="mt-4 font-montserrat text-xl font-semibold text-header-bg">
          2. Business Transfers:
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          In the event of a merger, acquisition, or sale of all or a portion of
          our business, your information may be transferred to the new entity.
        </p>
        <h4 className="mt-4 font-montserrat text-xl font-semibold text-header-bg">
          3. Legal Requirements:
        </h4>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          We may disclose your information if required by law, or in response to
          a valid legal request or government investigation.
        </p>
        <h2 className="mt-8 font-montserrat text-2xl font-semibold text-header-bg">
          Data Security
        </h2>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          We employ industry-standard security measures to protect your personal
          information from unauthorized access, alteration, disclosure, or
          destruction. However, no method of transmission over the internet or
          electronic storage is 100% secure. We cannot guarantee the absolute
          security of your data.
        </p>
        <h2 className="mt-8 font-montserrat text-2xl font-semibold text-header-bg">
          Your Choices
        </h2>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          You have the right to access, correct, or delete your personal
          information. You can update your account settings or contact us for
          assistance.
        </p>
        <h2 className="mt-8 font-montserrat text-2xl font-semibold text-header-bg">
          Children's Privacy
        </h2>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          Our website is not intended for individuals under the age of [insert
          age limit]. We do not knowingly collect personal information from
          children under this age. If you believe we have inadvertently
          collected information from a child, please contact us to have it
          removed.
        </p>
        <h2 className="mt-8 font-montserrat text-2xl font-semibold text-header-bg">
          Changes to this Privacy Policy
        </h2>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          We reserve the right to update this Privacy Policy at any time. We
          will notify you of any material changes through prominent notices on
          our website or via email.
        </p>
        <h2 className="mt-8 font-montserrat text-2xl font-semibold text-header-bg">
          Contact Us:
        </h2>
        <p className="text-light-blue font-poppins sm:text-base text-sm mt-3">
          If you have any questions or concerns about this Privacy Policy or our
          data practices, please contact us at coupondeals@gmail.com.
        </p>
      </div>
    </>
  );
};

export default PrivacyPolicy;

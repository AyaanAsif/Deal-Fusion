import React from "react";
import * as Icons from "../Global/Icons";
import { Link } from "react-router-dom";

const ForgotPassword: React.FC = () => {
  return (
    <>
      <div className="flex items-center h-screen bg-gray-100">
        <div className="grid md:grid-cols-2 grid-cols-1 2xl:container mx-auto xl:px-20 lg:px-10 px-5 h-11/12">
          <div className="p-6 md:rounded-tl-3xl md:rounded-bl-3xl rounded-2xl bg-white xl:py-6 py-16">
            <img src="/images/logo-blue.png" alt="" />
            <div className="flex flex-col items-center justify-center h-full">
              <div>
                <h2 className="text-header-bg font-montserrat lg:text-3xl md:text-2xl text-xl font-semibold">
                  Forgot Password?
                </h2>
                <p className="text-light-blue font-poppins text-sm mt-3">
                  No worries, we’ll send you reset instructions.
                </p>
                <p className="mt-6 text-header-bg font-poppins text-sm font-medium">
                  Email
                </p>
                <input
                  type="text"
                  placeholder="Enter your email"
                  className="w-full border border-gray-400 rounded-tr-xl rounded-bl-xl mt-2 h-12 px-2 font-montserrat"
                />
                <button className="mt-5 button w-full">Sign in</button>
                <Link to="/login">
                  <div className="flex items-center justify-center gap-3 mt-5">
                    <div className="rotate-180">
                      <Icons.rightArrowIcon />
                    </div>
                    <p className="text-primary font-sm font-poppins">
                      Back to login
                    </p>
                  </div>
                </Link>
              </div>
            </div>
          </div>
          <div className="md:grid hidden grid-cols-2 bg-white">
            <div className="lg:flex hidden items-center z-40 col-span-1">
              <img
                src="/images/log-in/img-2.png"
                alt=""
                className="ml-[100px] lg:block hidden"
              />
            </div>
            <div className="lg:col-span-1 col-span-2 relative flex justify-center items-center w-full">
              <img
                src="/images/log-in/img-1.png"
                alt=""
                className="h-full w-full rounded-tr-3xl rounded-br-3xl"
              />
              <img
                src="/images/log-in/img-2.png"
                alt=""
                className="absolute lg:hidden block w-72"
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ForgotPassword;

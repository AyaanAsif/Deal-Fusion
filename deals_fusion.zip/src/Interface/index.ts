export const IStoreDetails = {
  id: Number,
  storeName: String,
  storeHeading: String,
  storeDescription: String,
  couponDetails: [
    {
      id: Number,
      couponType: String,
      discount: Array,
      couponHeading: String,
      couponDates: String,
      couponDetails: {
        description: String,
        sellingDetails: String,
        expiryDetails: String,
        couponVerfication: String,
      },
    },
  ],
};
